import { CartItem, CustomerInfo, PaymentMethod, SalesRep } from '../types';

const formatPaymentMethod = (method: PaymentMethod): string => {
  switch (method) {
    case 'cash':
      return 'Efectivo';
    case 'transfer':
      return 'Transferencia Bancaria';
    case 'mercadopago':
      return 'Mercado Pago';
  }
};

const formatOrderMessage = (
  cart: CartItem[],
  customerInfo: CustomerInfo,
  paymentMethod: PaymentMethod,
  paymentProofUrl?: string,
  forSalesRep: boolean = false
): string => {
  const orderDetails = cart.map(item => 
    `• ${item.quantity}x ${item.name} - $${(item.price * item.quantity).toFixed(2)}`
  ).join('\n');

  const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  const message = [
    `🛍️ *${forSalesRep ? 'Nuevo Pedido Asignado' : 'Pedido Confirmado'}*\n`,
    `*Cliente:* ${customerInfo.name}`,
    `*Email:* ${customerInfo.email}`,
    `*Teléfono:* ${customerInfo.phone}`,
    customerInfo.notes ? `\n*Notas:*\n${customerInfo.notes}` : '',
    `\n*Método de Pago:*`,
    formatPaymentMethod(paymentMethod),
    paymentProofUrl ? `\n*Comprobante de Pago:*\n${paymentProofUrl}` : '',
    `\n*Detalles del Pedido:*`,
    orderDetails,
    `\n*Total:* $${total.toFixed(2)}`,
    `\n✅ *Estado:* ${forSalesRep ? 'Nuevo pedido para procesar' : 'Tu orden está preparándose'}`,
    forSalesRep ? '\nPor favor, procesa este pedido lo antes posible.' : '¡Gracias por tu compra! 🎉'
  ].filter(Boolean).join('\n');

  return message;
};

export const sendOrderNotification = (
  phoneNumber: string,
  cart: CartItem[],
  customerInfo: CustomerInfo,
  paymentMethod: PaymentMethod,
  paymentProofUrl?: string,
  forSalesRep: boolean = false
): Promise<void> => {
  return new Promise((resolve, reject) => {
    try {
      const message = formatOrderMessage(cart, customerInfo, paymentMethod, paymentProofUrl, forSalesRep);
      const encodedMessage = encodeURIComponent(message);
      const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodedMessage}`;
      
      // Open WhatsApp in a new window
      const newWindow = window.open(whatsappUrl, '_blank');
      
      if (newWindow) {
        resolve();
      } else {
        reject(new Error('El navegador bloqueó la apertura de WhatsApp. Por favor, permita las ventanas emergentes.'));
      }
    } catch (error) {
      reject(new Error('Error al enviar la notificación. Por favor, intente nuevamente.'));
    }
  });
};

export const notifySalesRep = async (
  salesRep: SalesRep,
  cart: CartItem[],
  customerInfo: CustomerInfo,
  paymentMethod: PaymentMethod,
  paymentProofUrl?: string
): Promise<void> => {
  if (!salesRep.phone) {
    throw new Error(`No hay número de teléfono disponible para ${salesRep.name}`);
  }

  const cleanPhone = salesRep.phone.replace(/\D/g, '');
  if (!cleanPhone.match(/^\d{10,}$/)) {
    throw new Error(`Número de teléfono inválido para ${salesRep.name}`);
  }

  await sendOrderNotification(
    cleanPhone,
    cart,
    customerInfo,
    paymentMethod,
    paymentProofUrl,
    true
  );
};