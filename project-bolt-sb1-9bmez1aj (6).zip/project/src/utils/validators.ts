export const validatePaymentProof = async (file: File): Promise<void> => {
  // Validate file type
  const allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'];
  if (!allowedTypes.includes(file.type)) {
    throw new Error('Por favor, adjunte una imagen (JPG, PNG, WebP) o PDF');
  }

  // Validate file size (max 5MB)
  const maxSize = 5 * 1024 * 1024; // 5MB in bytes
  if (file.size > maxSize) {
    throw new Error('El archivo no debe superar los 5MB');
  }

  // For images, validate dimensions
  if (file.type.startsWith('image/')) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      const url = URL.createObjectURL(file);
      
      img.onload = () => {
        URL.revokeObjectURL(url);
        
        // Check minimum dimensions (500x500)
        if (img.width < 500 || img.height < 500) {
          reject(new Error('La imagen debe ser al menos de 500x500 píxeles'));
          return;
        }

        // Check maximum dimensions (4000x4000)
        if (img.width > 4000 || img.height > 4000) {
          reject(new Error('La imagen no debe superar los 4000x4000 píxeles'));
          return;
        }

        resolve();
      };

      img.onerror = () => {
        URL.revokeObjectURL(url);
        reject(new Error('Error al procesar la imagen'));
      };

      img.src = url;
    });
  }

  return Promise.resolve();
};