export const validateFile = (file: File): Promise<void> => {
  return new Promise((resolve, reject) => {
    // Validate file type
    const allowedTypes = ['image/jpeg', 'image/png', 'application/pdf'];
    if (!allowedTypes.includes(file.type)) {
      reject(new Error('Por favor seleccione un archivo JPG, PNG o PDF'));
      return;
    }

    // Validate file size (5MB limit)
    if (file.size > 5 * 1024 * 1024) {
      reject(new Error('El archivo no debe superar los 5MB'));
      return;
    }

    // For images, validate dimensions
    if (file.type.startsWith('image/')) {
      const img = new Image();
      img.src = URL.createObjectURL(file);

      img.onload = () => {
        URL.revokeObjectURL(img.src);
        resolve();
      };

      img.onerror = () => {
        URL.revokeObjectURL(img.src);
        reject(new Error('Error al procesar la imagen'));
      };
    } else {
      // For PDFs, no additional validation needed
      resolve();
    }
  });
};