import { ImageDimensions } from '../types';

export const getOptimalDimensions = (
  originalWidth: number,
  originalHeight: number,
  maxDimension: number = 1080
): ImageDimensions => {
  const aspectRatio = originalWidth / originalHeight;

  if (originalWidth <= maxDimension && originalHeight <= maxDimension) {
    return { width: originalWidth, height: originalHeight };
  }

  if (aspectRatio > 1) {
    return {
      width: maxDimension,
      height: Math.round(maxDimension / aspectRatio),
    };
  } else {
    return {
      width: Math.round(maxDimension * aspectRatio),
      height: maxDimension,
    };
  }
};

export const optimizeImageUrl = (url: string, type: 'product' | 'category' | 'carousel' | 'header'): string => {
  if (!url.includes('unsplash.com')) return url;

  const dimensions: Record<string, ImageDimensions> = {
    product: { width: 1080, height: 1080 },
    category: { width: 800, height: 600 },
    carousel: { width: 1200, height: 800 },
    header: { width: 1600, height: 900 }
  };

  const { width, height } = dimensions[type];
  return `${url}${url.includes('?') ? '&' : '?'}w=${width}&h=${height}&fit=crop&q=80&auto=format`;
};