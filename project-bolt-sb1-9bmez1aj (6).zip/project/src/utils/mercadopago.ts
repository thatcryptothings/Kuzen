import { CartItem, CustomerInfo } from '../types';

export const generateMercadoPagoPreference = (
  cart: CartItem[],
  customerInfo: CustomerInfo,
  baseUrl: string
) => {
  // Calculate total amount
  const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  
  // Generate a unique order ID
  const orderId = `ORDER-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  
  // Create items description
  const itemsDescription = cart
    .map(item => `${item.quantity}x ${item.name}`)
    .join(', ');

  // Create payment link with dynamic parameters
  const params = new URLSearchParams({
    'preference-id': orderId,
    'external_reference': orderId,
    'description': `Pedido de ${customerInfo.name} - ${itemsDescription}`,
    'amount': total.toString(),
    'payer.email': customerInfo.email,
    'payer.name': customerInfo.name,
    'payer.phone': customerInfo.phone,
  });

  return {
    orderId,
    paymentUrl: `${baseUrl}?${params.toString()}`
  };
};