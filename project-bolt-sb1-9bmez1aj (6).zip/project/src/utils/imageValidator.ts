export const validateImage = (file: File): Promise<void> => {
  return new Promise((resolve, reject) => {
    // Validate file type
    if (!file.type.match(/^image\/(jpeg|png|webp)$/)) {
      reject(new Error('Por favor seleccione una imagen en formato JPG, PNG o WebP'));
      return;
    }

    // Validate file size (5MB limit)
    if (file.size > 5 * 1024 * 1024) {
      reject(new Error('La imagen no debe superar los 5MB'));
      return;
    }

    const img = new Image();
    img.src = URL.createObjectURL(file);

    img.onload = () => {
      URL.revokeObjectURL(img.src);

      // Check if dimensions are within allowed range (500x500 to 1200x1200)
      if (img.width > 1200 || img.height > 1200) {
        reject(new Error('La imagen no debe superar los 1200x1200 píxeles'));
        return;
      }

      // Check minimum dimensions (500x500)
      if (img.width < 500 || img.height < 500) {
        reject(new Error('La imagen debe ser al menos de 500x500 píxeles'));
        return;
      }

      resolve();
    };

    img.onerror = () => {
      URL.revokeObjectURL(img.src);
      reject(new Error('Error al procesar la imagen'));
    };
  });
};