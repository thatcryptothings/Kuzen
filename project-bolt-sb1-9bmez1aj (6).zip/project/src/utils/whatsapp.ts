import { CartItem, CustomerInfo, PaymentMethod } from '../types';

export const createWhatsAppUrl = (
  phoneNumber: string,
  message: string
): string => {
  const cleanPhone = phoneNumber.replace(/\D/g, '');
  if (!cleanPhone.match(/^\d{10,}$/)) {
    throw new Error('Número de teléfono inválido');
  }

  const encodedMessage = encodeURIComponent(message);
  return `https://wa.me/${cleanPhone}?text=${encodedMessage}`;
};

export const formatOrderMessage = (
  cart: CartItem[],
  customerInfo: CustomerInfo,
  paymentMethod: PaymentMethod,
  paymentProofUrl?: string,
  forSalesRep: boolean = false
): string => {
  const orderDetails = cart.map(item => 
    `• ${item.quantity}x ${item.name} - $${(item.price * item.quantity).toFixed(2)}`
  ).join('\n');

  const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  const message = [
    `🛍️ *${forSalesRep ? 'Nuevo Pedido Asignado' : 'Pedido Confirmado'}*\n`,
    `*Cliente:* ${customerInfo.name}`,
    `*Email:* ${customerInfo.email}`,
    `*Teléfono:* ${customerInfo.phone}`,
    customerInfo.notes ? `\n*Notas:*\n${customerInfo.notes}` : '',
    `\n*Método de Pago:*`,
    paymentMethod === 'cash' ? 'Efectivo' : 
    paymentMethod === 'transfer' ? 'Transferencia Bancaria' : 'Mercado Pago',
    paymentProofUrl ? `\n*Comprobante de Pago:*\n${paymentProofUrl}` : '',
    `\n*Detalles del Pedido:*`,
    orderDetails,
    `\n*Total:* $${total.toFixed(2)}`,
    `\n✅ *Estado:* ${forSalesRep ? 'Nuevo pedido para procesar' : 'Tu orden está preparándose'}`,
    forSalesRep ? '\nPor favor, procesa este pedido lo antes posible.' : '¡Gracias por tu compra! 🎉'
  ].filter(Boolean).join('\n');

  return message;
};