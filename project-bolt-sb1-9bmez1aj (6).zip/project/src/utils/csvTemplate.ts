import { Product } from '../types';

export const generateCSVTemplate = () => {
  const headers = [
    'id',
    'name',
    'description',
    'price',
    'imageUrl',
    'category',
    'labels',
    'stock',
    'size_value',
    'size_unit',
    'color',
  ];

  const sampleProduct: Product = {
    id: '1',
    name: 'Olla Hudson Professional 24cm',
    description: 'Olla de acero inoxidable con tapa de vidrio templado',
    price: 45999.99,
    imageUrl: 'https://images.unsplash.com/photo-1584990347449-a8f1d86dd69c',
    category: 'Ollas, Sartenes y Jarros',
    labels: ['Premium'],
    stock: 20,
    size: {
      value: 24,
      unit: 'cm'
    },
    color: 'Plateado'
  };

  const csvContent = [
    headers.join(','),
    [
      sampleProduct.id,
      `"${sampleProduct.name}"`,
      `"${sampleProduct.description}"`,
      sampleProduct.price,
      `"${sampleProduct.imageUrl}"`,
      `"${sampleProduct.category}"`,
      `"${sampleProduct.labels?.join(';')}"`,
      sampleProduct.stock,
      sampleProduct.size?.value || '',
      `"${sampleProduct.size?.unit || ''}"`,
      `"${sampleProduct.color || ''}"`,
    ].join(','),
  ].join('\n');

  return csvContent;
};