import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { StoreState } from '../types';
import { initialProducts } from '../data/initialProducts';
import { initialSalesReps } from '../data/salesReps';
import { createCustomStorage } from './storage';
import { createProductSlice } from './slices/productSlice';
import { createSalesRepSlice } from './slices/salesRepSlice';

export const useStore = create<StoreState>()(
  persist(
    (set, get) => ({
      // Initial state
      ...createProductSlice(set, get),
      ...createSalesRepSlice(set, get),
      
      cart: [],
      selectedCategory: null,
      searchQuery: '',
      paymentSettings: {
        transfer: {
          bankName: '',
          accountHolder: '',
          accountNumber: '',
          cbu: '',
          alias: '',
        },
        mercadoPago: {
          link: '',
          qrCode: '',
          username: '',
        },
      },

      // Initialize products and sales reps
      products: initialProducts.map(product => ({
        ...product,
        visible: true,
        sales: 0
      })),
      salesReps: initialSalesReps,

      // Cart actions
      addToCart: (product) =>
        set((state) => {
          const existingItem = state.cart.find((item) => item.id === product.id);
          const currentProduct = state.products.find(p => p.id === product.id);
          
          if (!currentProduct || currentProduct.stock <= 0) {
            throw new Error('Producto sin stock disponible');
          }

          if (existingItem) {
            if (existingItem.quantity >= currentProduct.stock) {
              throw new Error('No hay suficiente stock disponible');
            }

            return {
              cart: state.cart.map((item) =>
                item.id === product.id
                  ? { ...item, quantity: item.quantity + 1 }
                  : item
              ),
            };
          }

          return { 
            cart: [...state.cart, { ...product, quantity: 1 }]
          };
        }),

      removeFromCart: (productId) =>
        set((state) => ({
          cart: state.cart.filter((item) => item.id !== productId),
        })),

      updateQuantity: (productId, quantity) =>
        set((state) => {
          const product = state.products.find(p => p.id === productId);
          if (!product || quantity > product.stock) {
            throw new Error('No hay suficiente stock disponible');
          }

          return {
            cart: state.cart.map((item) =>
              item.id === productId ? { ...item, quantity } : item
            ),
          };
        }),

      clearCart: () => set({ cart: [] }),

      // Other actions
      setSelectedCategory: (category) => set({ selectedCategory: category }),
      setSearchQuery: (query) => set({ searchQuery: query }),
      updatePaymentSettings: (settings) => set({ paymentSettings: settings }),
    }),
    {
      name: 'store',
      storage: createCustomStorage(),
      partialize: (state) => ({
        cart: state.cart,
        paymentSettings: state.paymentSettings,
        salesReps: state.salesReps,
      }),
    }
  )
);