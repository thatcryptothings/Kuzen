import { StateCreator } from 'zustand';
import { Product } from '../../types';

export interface ProductSlice {
  products: Product[];
  visibleProducts: Product[];
  hiddenProducts: Product[];
  selectedCategory: string | null;
  searchQuery: string;
  
  setSelectedCategory: (category: string | null) => void;
  setSearchQuery: (query: string) => void;
  addProduct: (product: Omit<Product, 'id' | 'visible' | 'sales'>) => void;
  updateProduct: (id: string, updates: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  toggleProductVisibility: (id: string) => void;
}

export const createProductSlice: StateCreator<ProductSlice> = (set, get) => ({
  products: [],
  visibleProducts: [],
  hiddenProducts: [],
  selectedCategory: null,
  searchQuery: '',

  setSelectedCategory: (category) => set({ selectedCategory: category }),
  setSearchQuery: (query) => set({ searchQuery: query }),

  addProduct: (product) => 
    set((state) => {
      const newProduct = {
        ...product,
        id: Date.now().toString(),
        visible: true,
        sales: 0
      };
      
      return {
        products: [...state.products, newProduct],
        visibleProducts: [...state.visibleProducts, newProduct],
      };
    }),

  updateProduct: (id, updates) =>
    set((state) => {
      const updatedProducts = state.products.map((product) =>
        product.id === id ? { ...product, ...updates } : product
      );

      return {
        products: updatedProducts,
        visibleProducts: updatedProducts.filter(p => p.visible),
        hiddenProducts: updatedProducts.filter(p => !p.visible)
      };
    }),

  deleteProduct: (id) =>
    set((state) => {
      const filteredProducts = state.products.filter(p => p.id !== id);
      
      return {
        products: filteredProducts,
        visibleProducts: filteredProducts.filter(p => p.visible),
        hiddenProducts: filteredProducts.filter(p => !p.visible)
      };
    }),

  toggleProductVisibility: (id) =>
    set((state) => {
      const updatedProducts = state.products.map(product =>
        product.id === id 
          ? { ...product, visible: !product.visible }
          : product
      );

      return {
        products: updatedProducts,
        visibleProducts: updatedProducts.filter(p => p.visible),
        hiddenProducts: updatedProducts.filter(p => !p.visible)
      };
    })
});