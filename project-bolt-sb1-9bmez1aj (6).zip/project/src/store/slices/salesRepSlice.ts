import { StateCreator } from 'zustand';
import { SalesRep } from '../../types';

export interface SalesRepSlice {
  salesReps: SalesRep[];
  addSalesRep: (rep: Omit<SalesRep, 'id' | 'active' | 'totalSales'>) => void;
  updateSalesRep: (id: string, updates: Partial<SalesRep>) => void;
  toggleSalesRepStatus: (id: string) => void;
  deleteSalesRep: (id: string) => void;
}

export const createSalesRepSlice: StateCreator<SalesRepSlice> = (set) => ({
  salesReps: [],
  
  addSalesRep: (rep) => 
    set((state) => ({
      salesReps: [
        ...state.salesReps,
        {
          ...rep,
          id: Date.now().toString(),
          active: true,
          totalSales: 0
        }
      ]
    })),

  updateSalesRep: (id, updates) =>
    set((state) => ({
      salesReps: state.salesReps.map((rep) =>
        rep.id === id ? { ...rep, ...updates } : rep
      )
    })),

  toggleSalesRepStatus: (id) =>
    set((state) => ({
      salesReps: state.salesReps.map((rep) =>
        rep.id === id ? { ...rep, active: !rep.active } : rep
      )
    })),

  deleteSalesRep: (id) =>
    set((state) => ({
      salesReps: state.salesReps.filter((rep) => rep.id !== id)
    }))
});