import { StateStorage } from 'zustand/middleware';

const MAX_SIZE = 5 * 1024 * 1024; // 5MB limit

export const createCustomStorage = (): StateStorage => {
  return {
    getItem: (key: string): string | null => {
      try {
        return localStorage.getItem(key);
      } catch {
        return null;
      }
    },
    
    setItem: (key: string, value: string): void => {
      try {
        // Check size before storing
        if (value.length > MAX_SIZE) {
          // Parse the state
          const state = JSON.parse(value);
          
          // Create minimal state with only essential data
          const minimalState = {
            cart: state.cart,
            paymentSettings: state.paymentSettings,
            salesReps: state.salesReps?.map((rep: any) => ({
              id: rep.id,
              name: rep.name,
              phone: rep.phone,
              email: rep.email,
              active: rep.active,
              totalSales: rep.totalSales || 0
            }))
          };

          // Store minimal state
          localStorage.setItem(key, JSON.stringify(minimalState));
        } else {
          localStorage.setItem(key, value);
        }
      } catch (error) {
        // If storage fails, try to store only cart
        if (error instanceof Error && error.name === 'QuotaExceededError') {
          try {
            const state = JSON.parse(value);
            localStorage.setItem(key, JSON.stringify({ cart: state.cart }));
          } catch {
            // If all else fails, clear storage
            localStorage.removeItem(key);
          }
        }
      }
    },
    
    removeItem: (key: string): void => {
      try {
        localStorage.removeItem(key);
      } catch {
        // Ignore removal errors
      }
    }
  };
};