import React from 'react';
import { Package, DollarSign, BarChart2, Tags, TrendingUp, Clock } from 'lucide-react';
import { Product } from '../types';

interface AdminStatsProps {
  products: Product[];
}

export const AdminStats: React.FC<AdminStatsProps> = ({ products }) => {
  const totalProducts = products.length;
  const visibleProducts = products.filter(p => p.visible !== false).length;
  const totalStock = products.reduce((sum, p) => sum + p.stock, 0);
  const totalValue = products.reduce((sum, p) => sum + (p.price * p.stock), 0);
  const totalSales = products.reduce((sum, p) => sum + (p.sales || 0), 0);
  const totalRevenue = products.reduce((sum, p) => sum + ((p.sales || 0) * p.price), 0);
  const categories = new Set(products.map(p => p.category)).size;

  const stats = [
    {
      name: 'Productos Activos',
      value: `${visibleProducts} / ${totalProducts}`,
      icon: Package,
      color: 'bg-blue-500',
    },
    {
      name: 'Stock Total',
      value: totalStock,
      icon: BarChart2,
      color: 'bg-green-500',
    },
    {
      name: 'Valor del Inventario',
      value: `$${totalValue.toLocaleString()}`,
      icon: DollarSign,
      color: 'bg-purple-500',
    },
    {
      name: 'Categorías',
      value: categories,
      icon: Tags,
      color: 'bg-orange-500',
    },
    {
      name: 'Ventas Totales',
      value: totalSales,
      icon: TrendingUp,
      color: 'bg-indigo-500',
    },
    {
      name: 'Ingresos Totales',
      value: `$${totalRevenue.toLocaleString()}`,
      icon: Clock,
      color: 'bg-pink-500',
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
      {stats.map((stat) => (
        <div
          key={stat.name}
          className="bg-white rounded-lg shadow p-6 transition-transform hover:scale-[1.02]"
        >
          <div className="flex items-center">
            <div className={`${stat.color} p-3 rounded-lg`}>
              <stat.icon className="w-6 h-6 text-white" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-500">{stat.name}</p>
              <p className="text-xl font-semibold text-gray-900">{stat.value}</p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};