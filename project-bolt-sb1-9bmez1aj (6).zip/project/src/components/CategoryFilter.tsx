import React from 'react';
import { useStore } from '../store/useStore';

export const CategoryFilter: React.FC = () => {
  const products = useStore((state) => state.products);
  const selectedCategory = useStore((state) => state.selectedCategory);
  const setSelectedCategory = useStore((state) => state.setSelectedCategory);

  // Get unique categories and sort them alphabetically
  const categories = ['Todos', ...Array.from(new Set(products.map((product) => product.category)))
    .sort((a, b) => a.localeCompare(b))];

  return (
    <div className="overflow-x-auto -mx-4 mb-8">
      <div className="flex gap-3 px-4 pb-4 snap-x snap-mandatory min-w-full">
        {categories.map((category) => (
          <button
            key={category}
            onClick={() => setSelectedCategory(category === 'Todos' ? null : category)}
            className={`snap-start shrink-0 px-4 py-2.5 rounded-full text-base sm:text-sm transition-all duration-200 whitespace-nowrap ${
              (category === 'Todos' && selectedCategory === null) || category === selectedCategory
                ? 'bg-black text-white shadow-lg'
                : 'bg-white text-gray-700 shadow hover:bg-gray-50'
            }`}
          >
            {category}
          </button>
        ))}
      </div>
    </div>
  );
};