import React from 'react';
import { Search } from 'lucide-react';

interface SearchIconProps {
  className?: string;
  size?: number;
}

export const SearchIcon: React.FC<SearchIconProps> = ({ className = '', size = 20 }) => (
  <Search className={`${className}`} size={size} />
);