import React from 'react';
import { Package, BarChart2, Settings, LogOut } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export const AdminSidebar: React.FC = () => {
  const navigate = useNavigate();
  
  const handleLogout = () => {
    localStorage.removeItem('isAdmin');
    navigate('/');
  };

  return (
    <div className="w-64 bg-white shadow-lg h-screen">
      <div className="flex flex-col h-full">
        <div className="p-6">
          <h2 className="text-2xl font-bold text-gray-800">Panel Admin</h2>
        </div>
        
        <nav className="flex-1 px-4">
          <div className="space-y-2">
            <button className="flex items-center w-full px-4 py-3 text-gray-700 hover:bg-gray-100 rounded-lg">
              <Package className="w-5 h-5 mr-3" />
              Productos
            </button>
            <button className="flex items-center w-full px-4 py-3 text-gray-700 hover:bg-gray-100 rounded-lg">
              <BarChart2 className="w-5 h-5 mr-3" />
              Estadísticas
            </button>
            <button className="flex items-center w-full px-4 py-3 text-gray-700 hover:bg-gray-100 rounded-lg">
              <Settings className="w-5 h-5 mr-3" />
              Configuración
            </button>
          </div>
        </nav>

        <div className="p-4 border-t">
          <button
            onClick={handleLogout}
            className="flex items-center w-full px-4 py-3 text-red-600 hover:bg-red-50 rounded-lg"
          >
            <LogOut className="w-5 h-5 mr-3" />
            Cerrar Sesión
          </button>
        </div>
      </div>
    </div>
  );
};