import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ShoppingBag, Trash2, X, Send, Plus, Minus } from 'lucide-react';
import { useStore } from '../store/useStore';
import { CustomerForm } from './CustomerForm';
import { PaymentFlow } from './payment/PaymentFlow';
import { CustomerInfo, PaymentMethod } from '../types';

interface CartProps {
  isOpen: boolean;
  onClose: () => void;
}

export const Cart: React.FC<CartProps> = ({ isOpen, onClose }) => {
  const { cart, removeFromCart, updateQuantity, clearCart } = useStore();
  const [showCustomerForm, setShowCustomerForm] = useState(false);
  const [showPaymentFlow, setShowPaymentFlow] = useState(false);
  const [orderDetails, setOrderDetails] = useState<{
    customerInfo: CustomerInfo;
    paymentMethod: PaymentMethod;
  } | null>(null);

  const total = cart.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  const handleQuantityChange = (productId: string, newQuantity: number) => {
    if (newQuantity > 0) {
      updateQuantity(productId, newQuantity);
    }
  };

  const handleCustomerSubmit = (
    customerInfo: CustomerInfo,
    paymentMethod: PaymentMethod
  ) => {
    setOrderDetails({ customerInfo, paymentMethod });
    setShowCustomerForm(false);
    setShowPaymentFlow(true);
  };

  const handlePaymentComplete = () => {
    clearCart();
    setShowPaymentFlow(false);
    onClose();
  };

  const resetState = () => {
    setShowCustomerForm(false);
    setShowPaymentFlow(false);
    setOrderDetails(null);
  };

  const handleClose = () => {
    resetState();
    onClose();
  };

  return (
    <>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 z-40"
            onClick={handleClose}
          >
            {/* Cart content */}
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 20 }}
              className="fixed right-0 top-0 h-full w-full max-w-md bg-white shadow-xl z-50"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Cart header */}
              <div className="flex items-center justify-between p-4 border-b">
                <h2 className="text-lg font-semibold flex items-center">
                  <ShoppingBag className="w-5 h-5 mr-2" />
                  Carrito de Compras
                </h2>
                <button
                  onClick={handleClose}
                  className="p-2 hover:bg-gray-100 rounded-full"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Cart items */}
              {cart.length === 0 ? (
                <div className="flex-1 flex items-center justify-center p-8">
                  <div className="text-center">
                    <ShoppingBag className="w-16 h-16 mx-auto mb-4 text-gray-400" />
                    <p className="text-gray-500">Tu carrito está vacío</p>
                  </div>
                </div>
              ) : (
                <>
                  <div className="flex-1 overflow-y-auto p-4">
                    <div className="space-y-4">
                      {cart.map((item) => (
                        <motion.div
                          key={item.id}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -20 }}
                          className="flex items-center gap-4 bg-white p-4 rounded-lg shadow-sm"
                        >
                          {/* Item content */}
                          <img
                            src={item.imageUrl}
                            alt={item.name}
                            className="w-20 h-20 object-cover rounded-md"
                          />
                          <div className="flex-1 min-w-0">
                            <h3 className="font-medium text-sm">{item.name}</h3>
                            <p className="text-gray-500 text-sm">
                              ${item.price.toFixed(2)}
                            </p>
                            <div className="flex items-center gap-2 mt-2">
                              <button
                                onClick={() =>
                                  handleQuantityChange(item.id, item.quantity - 1)
                                }
                                className="p-1 hover:bg-gray-100 rounded"
                              >
                                <Minus className="w-4 h-4" />
                              </button>
                              <span className="w-8 text-center">
                                {item.quantity}
                              </span>
                              <button
                                onClick={() =>
                                  handleQuantityChange(item.id, item.quantity + 1)
                                }
                                className="p-1 hover:bg-gray-100 rounded"
                              >
                                <Plus className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                          <div className="flex flex-col items-end gap-2">
                            <span className="font-medium">
                              ${(item.price * item.quantity).toFixed(2)}
                            </span>
                            <button
                              onClick={() => removeFromCart(item.id)}
                              className="p-1 text-red-500 hover:bg-red-50 rounded"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </div>

                  {/* Cart footer */}
                  <div className="border-t p-4 space-y-4">
                    <div className="flex justify-between items-center font-semibold text-lg">
                      <span>Total</span>
                      <span>${total.toFixed(2)}</span>
                    </div>
                    <button
                      onClick={() => setShowCustomerForm(true)}
                      className="w-full bg-green-600 text-white py-3 rounded-lg hover:bg-green-700 transition-colors flex items-center justify-center"
                    >
                      <Send className="w-5 h-5 mr-2" />
                      Completar Pedido
                    </button>
                  </div>
                </>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Customer form */}
      <AnimatePresence>
        {showCustomerForm && (
          <CustomerForm
            onSubmit={handleCustomerSubmit}
            onCancel={() => setShowCustomerForm(false)}
          />
        )}
      </AnimatePresence>

      {/* Payment flow */}
      <AnimatePresence>
        {showPaymentFlow && orderDetails && (
          <PaymentFlow
            cart={cart}
            customerInfo={orderDetails.customerInfo}
            paymentMethod={orderDetails.paymentMethod}
            onComplete={handlePaymentComplete}
            onCancel={() => setShowPaymentFlow(false)}
          />
        )}
      </AnimatePresence>
    </>
  );
};