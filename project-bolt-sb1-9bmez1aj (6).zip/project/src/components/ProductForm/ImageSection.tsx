import React from 'react';
import { ImageUploader } from '../ImageUploader';
import { ImagePreview } from '../ImagePreview';

interface ImageSectionProps {
  images: string[];
  error: string | null;
  onImageUpload: (file: File) => void;
  onRemoveImage: (index: number) => void;
}

export const ImageSection: React.FC<ImageSectionProps> = ({
  images,
  error,
  onImageUpload,
  onRemoveImage,
}) => {
  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">
        Imágenes (500x500px - 1200x1200px)
      </label>
      <p className="text-sm text-gray-500 mb-2">
        Puedes subir hasta 4 imágenes. La primera imagen será la principal.
      </p>
      
      <ImageUploader
        onImageSelect={onImageUpload}
        label={images.length >= 4 ? 'Límite alcanzado' : 'Subir imagen'}
        disabled={images.length >= 4}
        className="w-full"
      />
      
      {error && (
        <p className="mt-2 text-sm text-red-600">{error}</p>
      )}
      
      {images.length > 0 && (
        <ImagePreview
          images={images}
          onRemove={onRemoveImage}
        />
      )}
    </div>
  );
};