import React from 'react';

interface FormActionsProps {
  onCancel: () => void;
  isEdit: boolean;
}

export const FormActions: React.FC<FormActionsProps> = ({
  onCancel,
  isEdit,
}) => {
  return (
    <div className="flex gap-2 pt-4">
      <button
        type="button"
        onClick={onCancel}
        className="flex-1 px-4 py-2 border rounded-lg hover:bg-gray-100"
      >
        Cancelar
      </button>
      <button
        type="submit"
        className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
      >
        {isEdit ? 'Guardar Cambios' : 'Crear Producto'}
      </button>
    </div>
  );
};