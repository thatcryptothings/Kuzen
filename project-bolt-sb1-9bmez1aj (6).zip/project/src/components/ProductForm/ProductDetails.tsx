import React from 'react';
import { Product } from '../../types';
import { FormInput } from '../form/FormInput';
import { FormSelect } from '../form/FormSelect';
import { FormTextArea } from '../form/FormTextArea';
import { FormToggle } from '../form/FormToggle';
import { categories } from '../../constants/categories';

interface ProductDetailsProps {
  formData: Partial<Product>;
  onChange: (field: keyof Product | 'size', value: any) => void;
}

export const ProductDetails: React.FC<ProductDetailsProps> = ({
  formData,
  onChange,
}) => {
  const handleSizeChange = (
    dimension: 'width' | 'height',
    field: 'value' | 'unit',
    value: number | string
  ) => {
    onChange('size', {
      ...formData.size,
      [dimension]: {
        ...(formData.size?.[dimension] || { value: 0, unit: 'cm' }),
        [field]: value
      }
    });
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <FormInput
          label="Nombre"
          type="text"
          required
          value={formData.name || ''}
          onChange={(e) => onChange('name', e.target.value)}
        />

        <FormSelect
          label="Categoría"
          required
          value={formData.category || ''}
          onChange={(e) => onChange('category', e.target.value)}
          options={categories.map(category => ({
            value: category,
            label: category
          }))}
        />

        <FormInput
          label="Precio"
          type="number"
          required
          min="0"
          step="0.01"
          value={formData.price?.toString() || '0'}
          onChange={(e) => onChange('price', parseFloat(e.target.value) || 0)}
        />

        <FormInput
          label="Stock"
          type="number"
          required
          min="0"
          value={formData.stock?.toString() || '0'}
          onChange={(e) => onChange('stock', parseInt(e.target.value) || 0)}
        />

        {/* Width measurement */}
        <div className="flex gap-2">
          <div className="flex-1">
            <FormInput
              label="Ancho"
              type="number"
              min="0"
              step="0.1"
              value={formData.size?.width?.value?.toString() || '0'}
              onChange={(e) => handleSizeChange('width', 'value', parseFloat(e.target.value) || 0)}
            />
          </div>
          <div className="w-24">
            <FormSelect
              label="Unidad"
              value={formData.size?.width?.unit || 'cm'}
              onChange={(e) => handleSizeChange('width', 'unit', e.target.value)}
              options={[
                { value: 'cm', label: 'cm' },
                { value: 'in', label: 'in' }
              ]}
            />
          </div>
        </div>

        {/* Height measurement */}
        <div className="flex gap-2">
          <div className="flex-1">
            <FormInput
              label="Alto"
              type="number"
              min="0"
              step="0.1"
              value={formData.size?.height?.value?.toString() || '0'}
              onChange={(e) => handleSizeChange('height', 'value', parseFloat(e.target.value) || 0)}
            />
          </div>
          <div className="w-24">
            <FormSelect
              label="Unidad"
              value={formData.size?.height?.unit || 'cm'}
              onChange={(e) => handleSizeChange('height', 'unit', e.target.value)}
              options={[
                { value: 'cm', label: 'cm' },
                { value: 'in', label: 'in' }
              ]}
            />
          </div>
        </div>

        <FormInput
          label="Color"
          type="text"
          value={formData.color || ''}
          onChange={(e) => onChange('color', e.target.value)}
        />

        <div className="col-span-2">
          <FormToggle
            label="Mostrar en catálogo"
            checked={formData.visible !== false}
            onChange={(checked) => onChange('visible', checked)}
            description="Activar para mostrar este producto en el catálogo"
          />
        </div>
      </div>

      <FormTextArea
        label="Descripción"
        required
        value={formData.description || ''}
        onChange={(e) => onChange('description', e.target.value)}
        rows={3}
      />
    </div>
  );
};