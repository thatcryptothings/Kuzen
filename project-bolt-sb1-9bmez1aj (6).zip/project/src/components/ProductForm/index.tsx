import React from 'react';
import { motion } from 'framer-motion';
import { X } from 'lucide-react';
import { Product } from '../../types';
import { useProductForm } from '../../hooks/useProductForm';
import { ImageSection } from './ImageSection';
import { ProductDetails } from './ProductDetails';
import { FormActions } from './FormActions';

interface ProductFormProps {
  product?: Product | null;
  onSubmit: (product: Product) => void;
  onCancel: () => void;
}

export const ProductForm: React.FC<ProductFormProps> = ({
  product,
  onSubmit,
  onCancel,
}) => {
  const {
    formData,
    images,
    error,
    handleInputChange,
    handleImageUpload,
    handleRemoveImage,
    handleSubmit,
  } = useProductForm(product, onSubmit);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
    >
      <motion.div
        initial={{ scale: 0.95 }}
        animate={{ scale: 1 }}
        className="bg-white rounded-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto"
      >
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-xl font-semibold">
            {product ? 'Editar Producto' : 'Nuevo Producto'}
          </h3>
          <button onClick={onCancel} className="text-gray-500 hover:text-gray-700">
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <ImageSection
            images={images}
            error={error}
            onImageUpload={handleImageUpload}
            onRemoveImage={handleRemoveImage}
          />

          <ProductDetails
            formData={formData}
            onChange={handleInputChange}
          />

          <FormActions
            onCancel={onCancel}
            isEdit={!!product}
          />
        </form>
      </motion.div>
    </motion.div>
  );
};