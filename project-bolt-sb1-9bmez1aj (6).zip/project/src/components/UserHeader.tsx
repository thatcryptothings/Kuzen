import React from 'react';
import { Link } from 'react-router-dom';
import { ShoppingCart } from 'lucide-react';
import { useStore } from '../store/useStore';

interface UserHeaderProps {
  onCartClick: () => void;
}

export const UserHeader: React.FC<UserHeaderProps> = ({ onCartClick }) => {
  const cart = useStore((state) => state.cart || []);

  return (
    <header className="bg-white shadow-sm">
      <div className="relative h-64">
        <img
          src="https://images.unsplash.com/photo-1556911220-bff31c812dba?w=1600&q=80"
          alt="Kitchen Utensils"
          className="w-full h-full object-cover"
        />
      </div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex justify-between items-center">
          <nav className="flex gap-4">
            <Link to="/" className="text-gray-700 hover:text-gray-900">
              Categorías
            </Link>
            <Link to="/products" className="text-gray-700 hover:text-gray-900">
              Productos
            </Link>
          </nav>
          <button
            onClick={onCartClick}
            className="relative p-2 hover:bg-gray-100 rounded-full"
          >
            <ShoppingCart className="w-6 h-6" />
            {cart.length > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs w-5 h-5 flex items-center justify-center rounded-full">
                {cart.length}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};