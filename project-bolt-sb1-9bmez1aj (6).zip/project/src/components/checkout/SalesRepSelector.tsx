import React from 'react';
import { useSalesReps } from '../../hooks/useSalesReps';

interface SalesRepSelectorProps {
  value: string;
  onChange: (value: string) => void;
  error?: string;
}

export const SalesRepSelector: React.FC<SalesRepSelectorProps> = ({
  value,
  onChange,
  error
}) => {
  const { activeSalesReps } = useSalesReps();

  if (activeSalesReps.length === 0) {
    return (
      <div className="text-sm text-red-600">
        No hay vendedoras disponibles en este momento
      </div>
    );
  }

  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">
        Vendedora *
      </label>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        required
        className={`w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 ${
          error ? 'border-red-500' : 'border-gray-300'
        }`}
      >
        <option value="">Seleccionar vendedora</option>
        {activeSalesReps.map((rep) => (
          <option key={rep.id} value={rep.id}>
            {rep.name}
          </option>
        ))}
      </select>
      {error && (
        <p className="mt-1 text-sm text-red-600">{error}</p>
      )}
    </div>
  );
};