import React from 'react';
import { PaymentMethod } from '../../types';

interface PaymentMethodSelectorProps {
  value: PaymentMethod;
  onChange: (method: PaymentMethod) => void;
}

export const PaymentMethodSelector: React.FC<PaymentMethodSelectorProps> = ({
  value,
  onChange,
}) => {
  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">
        Método de Pago
      </label>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value as PaymentMethod)}
        className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
      >
        <option value="cash">Efectivo</option>
        <option value="transfer">Transferencia Bancaria</option>
        <option value="mercadopago">Mercado Pago</option>
      </select>
    </div>
  );
};