import React from 'react';
import { CartItem, CustomerInfo, PaymentMethod } from '../../types';
import { useStore } from '../../store/useStore';
import { useNotification } from '../../hooks/useNotification';
import { createWhatsAppUrl, formatOrderMessage } from '../../utils/whatsapp';
import { PaymentProofUploader } from './PaymentProofUploader';
import { ConfirmationDialog } from '../common/ConfirmationDialog';

interface PaymentConfirmationProps {
  cart: CartItem[];
  customerInfo: CustomerInfo;
  paymentMethod: PaymentMethod;
  onComplete: () => void;
  onCancel: () => void;
}

export const PaymentConfirmation: React.FC<PaymentConfirmationProps> = ({
  cart,
  customerInfo,
  paymentMethod,
  onComplete,
  onCancel,
}) => {
  const { salesReps } = useStore();
  const [paymentProofUrl, setPaymentProofUrl] = React.useState<string>('');
  
  const { isLoading, error, sendNotification, clearError } = useNotification({
    onSuccess: onComplete
  });

  const selectedSalesRep = salesReps.find(
    rep => rep.name === customerInfo.salesRep && rep.active
  );

  const handleConfirm = async () => {
    if (!selectedSalesRep?.phone) {
      alert('No se encontró el número de teléfono de la vendedora');
      return;
    }

    if (paymentMethod !== 'cash' && !paymentProofUrl) {
      alert('Por favor, adjunte el comprobante de pago');
      return;
    }

    const message = formatOrderMessage(
      cart,
      customerInfo,
      paymentMethod,
      paymentProofUrl,
      true
    );

    try {
      const whatsappUrl = createWhatsAppUrl(selectedSalesRep.phone, message);
      await sendNotification(whatsappUrl);
    } catch (err) {
      alert(err instanceof Error ? err.message : 'Error al enviar la notificación');
    }
  };

  return (
    <ConfirmationDialog
      title="Confirmar Pedido"
      isOpen={true}
      onClose={onCancel}
    >
      <div className="space-y-4">
        {selectedSalesRep && (
          <div className="bg-gray-50 p-4 rounded-lg">
            <p className="text-sm text-gray-600">
              Vendedora asignada: <span className="font-medium">{selectedSalesRep.name}</span>
            </p>
          </div>
        )}

        {paymentMethod !== 'cash' && (
          <PaymentProofUploader
            onFileUploaded={setPaymentProofUrl}
            onError={clearError}
          />
        )}

        {error && (
          <p className="text-sm text-red-600">{error}</p>
        )}

        <div className="flex gap-2 pt-4">
          <button
            onClick={onCancel}
            disabled={isLoading}
            className="flex-1 px-4 py-2 border rounded-lg hover:bg-gray-100"
          >
            Cancelar
          </button>
          <button
            onClick={handleConfirm}
            disabled={isLoading}
            className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50"
          >
            {isLoading ? 'Enviando...' : 'Confirmar y Enviar'}
          </button>
        </div>
      </div>
    </ConfirmationDialog>
  );
};