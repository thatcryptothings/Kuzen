import React from 'react';
import { Upload } from 'lucide-react';
import { validatePaymentProof } from '../../utils/validators';

interface PaymentProofUploaderProps {
  onFileUploaded: (url: string) => void;
  onError: (error: string) => void;
}

export const PaymentProofUploader: React.FC<PaymentProofUploaderProps> = ({
  onFileUploaded,
  onError,
}) => {
  const [fileName, setFileName] = React.useState('');

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      await validatePaymentProof(file);
      
      const reader = new FileReader();
      reader.onload = () => {
        onFileUploaded(reader.result as string);
        setFileName(file.name);
      };
      reader.onerror = () => {
        onError('Error al procesar el archivo');
      };
      reader.readAsDataURL(file);
    } catch (err) {
      onError(err instanceof Error ? err.message : 'Error al procesar el archivo');
    }
  };

  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-2">
        Comprobante de Pago
      </label>
      <label className="flex items-center justify-center px-4 py-2 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
        <Upload className="w-5 h-5 mr-2 text-gray-500" />
        <span className="text-sm text-gray-600">
          {fileName || 'Subir comprobante'}
        </span>
        <input
          type="file"
          accept="image/*,.pdf"
          onChange={handleFileChange}
          className="hidden"
        />
      </label>
    </div>
  );
};