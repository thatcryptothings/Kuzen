import React from 'react';
import { CustomerInfo, PaymentMethod, SalesRep } from '../../types';
import { PaymentMethodSelector } from './PaymentMethodSelector';
import { SalesRepSelector } from './SalesRepSelector';
import { FormInput } from '../form/FormInput';
import { FormTextArea } from '../form/FormTextArea';

interface CustomerFormProps {
  onSubmit: (customerInfo: CustomerInfo, paymentMethod: PaymentMethod) => void;
  onCancel: () => void;
}

export const CustomerForm: React.FC<CustomerFormProps> = ({ onSubmit, onCancel }) => {
  const [formData, setFormData] = React.useState<CustomerInfo>({
    name: '',
    email: '',
    phone: '',
    notes: '',
    salesRep: '',
  });
  const [paymentMethod, setPaymentMethod] = React.useState<PaymentMethod>('cash');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData, paymentMethod);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-[480px] max-w-full mx-4">
        <h3 className="text-xl font-semibold mb-4">Completar Pedido</h3>
        <form onSubmit={handleSubmit} className="space-y-4">
          <FormInput
            label="Nombre Completo"
            type="text"
            required
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            placeholder="Ingrese su nombre completo"
          />

          <FormInput
            label="Correo Electrónico"
            type="email"
            required
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            placeholder="Ingrese su correo electrónico"
          />

          <FormInput
            label="Teléfono"
            type="tel"
            required
            value={formData.phone}
            onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
            placeholder="Ingrese su número de teléfono"
          />

          <SalesRepSelector
            value={formData.salesRep}
            onChange={(value) => setFormData({ ...formData, salesRep: value })}
          />

          <FormTextArea
            label="Notas (Opcional)"
            value={formData.notes}
            onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
            placeholder="Notas adicionales para su pedido"
            rows={3}
          />

          <PaymentMethodSelector
            value={paymentMethod}
            onChange={setPaymentMethod}
          />

          <div className="flex gap-2 pt-4">
            <button
              type="button"
              onClick={onCancel}
              className="flex-1 px-4 py-2 border rounded-lg hover:bg-gray-100"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
            >
              Continuar
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};