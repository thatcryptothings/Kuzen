import React from 'react';
import { Users } from 'lucide-react';
import { Product } from '../../types';

interface CustomerOverviewProps {
  products: Product[];
}

export const CustomerOverview: React.FC<CustomerOverviewProps> = ({ products }) => {
  // Calculate customer metrics
  const totalSales = products.reduce((sum, p) => sum + (p.sales || 0), 0);
  const averageOrderValue = products.reduce((sum, p) => sum + (p.sales || 0) * p.price, 0) / totalSales;
  
  const metrics = [
    {
      label: 'Total de Ventas',
      value: totalSales,
    },
    {
      label: 'Valor Promedio de Orden',
      value: `$${averageOrderValue.toFixed(2)}`,
    },
    {
      label: 'Productos Diferentes Vendidos',
      value: products.filter(p => (p.sales || 0) > 0).length,
    },
  ];

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-gray-900">Resumen de Clientes</h3>
        <Users className="w-5 h-5 text-purple-500" />
      </div>

      <div className="grid grid-cols-1 gap-4">
        {metrics.map((metric) => (
          <div
            key={metric.label}
            className="bg-gray-50 rounded-lg p-4"
          >
            <p className="text-sm text-gray-500">{metric.label}</p>
            <p className="text-xl font-semibold text-gray-900 mt-1">
              {metric.value}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};