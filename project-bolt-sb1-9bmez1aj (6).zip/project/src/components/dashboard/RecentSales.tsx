import React from 'react';
import { Clock } from 'lucide-react';
import { Product } from '../../types';

interface RecentSalesProps {
  products: Product[];
}

export const RecentSales: React.FC<RecentSalesProps> = ({ products }) => {
  const recentSales = products
    .filter(p => p.lastSale)
    .sort((a, b) => new Date(b.lastSale!).getTime() - new Date(a.lastSale!).getTime())
    .slice(0, 5);

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-gray-900">Ventas Recientes</h3>
        <Clock className="w-5 h-5 text-blue-500" />
      </div>

      <div className="space-y-4">
        {recentSales.map((product) => (
          <div key={product.id} className="flex items-center">
            <img
              src={product.imageUrl}
              alt={product.name}
              className="w-12 h-12 rounded-lg object-cover"
            />
            <div className="ml-4 flex-1">
              <p className="text-sm font-medium text-gray-900">{product.name}</p>
              <p className="text-xs text-gray-500">
                {new Date(product.lastSale!).toLocaleDateString()}
              </p>
            </div>
            <div className="text-right">
              <p className="text-sm font-medium text-gray-900">
                ${product.price.toFixed(2)}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};