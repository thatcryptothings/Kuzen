import React from 'react';
import { Users, ShoppingBag, CreditCard } from 'lucide-react';
import { CustomerInfo, Product } from '../../types';

interface CustomerStatsProps {
  customers: CustomerInfo[];
  products: Product[];
}

export const CustomerStats: React.FC<CustomerStatsProps> = ({ customers, products }) => {
  const totalSales = products.reduce((sum, p) => sum + (p.sales || 0), 0);
  const averageOrderValue = products.reduce((sum, p) => sum + ((p.sales || 0) * p.price), 0) / totalSales;

  const stats = [
    {
      name: 'Total Clientes',
      value: customers.length,
      icon: Users,
      color: 'bg-blue-500'
    },
    {
      name: 'Total Pedidos',
      value: totalSales,
      icon: ShoppingBag,
      color: 'bg-green-500'
    },
    {
      name: 'Valor Promedio',
      value: `$${averageOrderValue.toFixed(2)}`,
      icon: CreditCard,
      color: 'bg-purple-500'
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      {stats.map((stat) => (
        <div
          key={stat.name}
          className="bg-white rounded-lg shadow p-6 flex items-center"
        >
          <div className={`${stat.color} p-3 rounded-lg`}>
            <stat.icon className="w-6 h-6 text-white" />
          </div>
          <div className="ml-4">
            <p className="text-sm font-medium text-gray-500">{stat.name}</p>
            <p className="text-xl font-semibold text-gray-900">{stat.value}</p>
          </div>
        </div>
      ))}
    </div>
  );
};