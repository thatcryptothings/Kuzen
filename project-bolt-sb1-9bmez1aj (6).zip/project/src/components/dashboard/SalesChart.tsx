import React from 'react';
import { BarChart2 } from 'lucide-react';
import { Product } from '../../types';

interface SalesChartProps {
  products: Product[];
}

export const SalesChart: React.FC<SalesChartProps> = ({ products }) => {
  // Group sales by category
  const salesByCategory = products.reduce((acc, product) => {
    const category = product.category;
    if (!acc[category]) {
      acc[category] = 0;
    }
    acc[category] += product.sales || 0;
    return acc;
  }, {} as Record<string, number>);

  // Sort categories by sales
  const sortedCategories = Object.entries(salesByCategory)
    .sort(([, a], [, b]) => b - a);

  // Find the maximum sales value for scaling
  const maxSales = Math.max(...Object.values(salesByCategory));

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-gray-900">Ventas por Categoría</h3>
        <BarChart2 className="w-5 h-5 text-indigo-500" />
      </div>

      <div className="space-y-4">
        {sortedCategories.map(([category, sales]) => (
          <div key={category}>
            <div className="flex justify-between text-sm mb-1">
              <span className="text-gray-600">{category}</span>
              <span className="text-gray-900 font-medium">{sales}</span>
            </div>
            <div className="w-full bg-gray-100 rounded-full h-2">
              <div
                className="bg-indigo-500 h-2 rounded-full"
                style={{ width: `${(sales / maxSales) * 100}%` }}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};