import React from 'react';
import { Copy } from 'lucide-react';
import { useCopyToClipboard } from '../../hooks/useCopyToClipboard';

interface CopyableFieldProps {
  label: string;
  value: string;
  monospace?: boolean;
  isLink?: boolean;
}

export const CopyableField: React.FC<CopyableFieldProps> = ({
  label,
  value,
  monospace = false,
  isLink = false,
}) => {
  const { copyToClipboard } = useCopyToClipboard();

  return (
    <div>
      <p className="text-sm font-medium text-gray-700">{label}</p>
      <div className="flex items-center gap-2">
        {isLink ? (
          <a
            href={value}
            target="_blank"
            rel="noopener noreferrer"
            className="text-blue-600 hover:underline truncate flex-1"
          >
            {value}
          </a>
        ) : (
          <p className={`text-base break-all flex-1 ${monospace ? 'font-mono' : ''}`}>
            {value}
          </p>
        )}
        <button
          onClick={() => copyToClipboard(value)}
          className="p-1 hover:bg-gray-100 rounded flex-shrink-0"
          title="Copiar al portapapeles"
        >
          <Copy className="w-4 h-4 text-gray-500" />
        </button>
      </div>
    </div>
  );
};