import React, { useState } from 'react';
import { Check, Upload, Send, FileType, Phone } from 'lucide-react';
import { CartItem, CustomerInfo, PaymentMethod } from '../../types';
import { sendOrderNotification, notifySalesRep } from '../../utils/orderNotifications';
import { validateFile } from '../../utils/fileValidator';
import { useStore } from '../../store/useStore';

// ... (rest of the imports)

export const PaymentConfirmation: React.FC<PaymentConfirmationProps> = ({
  cart,
  customerInfo,
  paymentMethod,
  onClose,
  onCancel,
}) => {
  const { salesReps } = useStore();
  // ... (existing state)

  const handleConfirmPayment = async () => {
    if (!paymentProof && (paymentMethod === 'transfer' || paymentMethod === 'mercadopago')) {
      setError('Por favor, sube el comprobante de pago');
      return;
    }

    const phoneValidationError = validatePhoneNumber(phoneNumber);
    if (phoneValidationError) {
      setPhoneError(phoneValidationError);
      return;
    }

    setIsUploading(true);
    try {
      let paymentProofUrl = '';
      
      if (paymentProof) {
        paymentProofUrl = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onloadend = () => resolve(reader.result as string);
          reader.onerror = () => reject(new Error('Error al procesar el archivo'));
          reader.readAsDataURL(paymentProof);
        });
      }

      // Send order notification to customer
      sendOrderNotification(
        phoneNumber.replace(/\D/g, ''),
        cart,
        customerInfo,
        paymentMethod,
        paymentProofUrl
      );

      // Find and notify the assigned sales rep
      const assignedRep = salesReps.find(
        rep => rep.active && rep.name === customerInfo.salesRep
      );
      
      if (assignedRep?.phone) {
        notifySalesRep(
          assignedRep,
          cart,
          customerInfo,
          paymentMethod,
          paymentProofUrl
        );
      }

      onClose(true);
    } catch (error) {
      setError('Error al procesar el pago. Por favor, intenta nuevamente.');
    } finally {
      setIsUploading(false);
    }
  };

  // ... (rest of the component)
};