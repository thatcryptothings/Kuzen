import React, { useState } from 'react';
import { Upload, Send } from 'lucide-react';
import { CartItem, CustomerInfo, PaymentMethod } from '../../types';
import { useStore } from '../../store/useStore';
import { notifySalesRep } from '../../utils/orderNotifications';
import { validatePaymentProof } from '../../utils/validators';

interface PaymentConfirmationDialogProps {
  cart: CartItem[];
  customerInfo: CustomerInfo;
  paymentMethod: PaymentMethod;
  onClose: () => void;
}

export const PaymentConfirmationDialog: React.FC<PaymentConfirmationDialogProps> = ({
  cart,
  customerInfo,
  paymentMethod,
  onClose,
}) => {
  const { salesReps } = useStore();
  const [paymentProof, setPaymentProof] = useState<File | null>(null);
  const [error, setError] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);

  const selectedSalesRep = salesReps.find(rep => rep.name === customerInfo.salesRep && rep.active);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      await validatePaymentProof(file);
      setPaymentProof(file);
      setError('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error al procesar el archivo');
    }
  };

  const handleConfirm = async () => {
    if (!selectedSalesRep) {
      setError('No se encontró la vendedora seleccionada o está inactiva');
      return;
    }

    if (paymentMethod !== 'cash' && !paymentProof) {
      setError('Por favor, adjunte el comprobante de pago');
      return;
    }

    setIsLoading(true);
    try {
      let paymentProofUrl = '';
      if (paymentProof) {
        paymentProofUrl = await new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result as string);
          reader.onerror = reject;
          reader.readAsDataURL(paymentProof);
        });
      }

      await notifySalesRep(
        selectedSalesRep,
        cart,
        customerInfo,
        paymentMethod,
        paymentProofUrl
      );

      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error al enviar la notificación. Por favor, intente nuevamente.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-[480px] max-w-full mx-4">
        <h3 className="text-xl font-semibold mb-4">Confirmar Pedido</h3>
        
        <div className="space-y-4">
          {selectedSalesRep && (
            <div className="bg-gray-50 p-4 rounded-lg">
              <p className="text-sm text-gray-600">
                Vendedora asignada: <span className="font-medium">{selectedSalesRep.name}</span>
              </p>
            </div>
          )}

          {paymentMethod !== 'cash' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Comprobante de Pago
              </label>
              <div className="flex items-center gap-2">
                <label className="flex-1">
                  <div className="flex items-center justify-center px-4 py-2 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
                    <Upload className="w-5 h-5 mr-2 text-gray-500" />
                    <span className="text-sm text-gray-600">
                      {paymentProof ? paymentProof.name : 'Subir comprobante'}
                    </span>
                  </div>
                  <input
                    type="file"
                    accept="image/*,.pdf"
                    onChange={handleFileChange}
                    className="hidden"
                  />
                </label>
              </div>
            </div>
          )}

          {error && (
            <p className="text-sm text-red-600">{error}</p>
          )}

          <div className="flex gap-2 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 border rounded-lg hover:bg-gray-100"
              disabled={isLoading}
            >
              Cancelar
            </button>
            <button
              onClick={handleConfirm}
              disabled={isLoading}
              className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50 flex items-center justify-center gap-2"
            >
              <Send className="w-4 h-4" />
              {isLoading ? 'Enviando...' : 'Enviar a Vendedora'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};