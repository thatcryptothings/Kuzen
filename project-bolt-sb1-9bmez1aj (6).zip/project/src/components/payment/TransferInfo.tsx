import React from 'react';
import { AlertCircle } from 'lucide-react';
import { PaymentSettings } from '../../types';
import { CopyableField } from './CopyableField';

interface TransferInfoProps {
  settings: PaymentSettings['transfer'];
}

export const TransferInfo: React.FC<TransferInfoProps> = ({ settings }) => {
  const isConfigured = settings.bankName && settings.accountHolder && settings.cbu;

  if (!isConfigured) {
    return (
      <div className="flex items-center gap-2 text-yellow-600">
        <AlertCircle className="w-5 h-5" />
        <p>La información de transferencia no está configurada</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div>
        <p className="text-sm font-medium text-gray-700">Banco</p>
        <p className="text-base">{settings.bankName}</p>
      </div>
      
      <div>
        <p className="text-sm font-medium text-gray-700">Titular</p>
        <p className="text-base">{settings.accountHolder}</p>
      </div>

      {settings.accountNumber && (
        <CopyableField
          label="Número de Cuenta"
          value={settings.accountNumber}
          monospace
        />
      )}

      <CopyableField
        label="CBU"
        value={settings.cbu}
        monospace
      />

      {settings.alias && (
        <CopyableField
          label="Alias"
          value={settings.alias}
          monospace
        />
      )}
    </div>
  );
};