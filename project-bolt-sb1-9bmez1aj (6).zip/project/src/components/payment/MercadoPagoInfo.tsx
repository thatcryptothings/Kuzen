import React from 'react';
import { AlertCircle } from 'lucide-react';
import { PaymentSettings, CartItem, CustomerInfo } from '../../types';
import { CopyableField } from './CopyableField';
import { generateMercadoPagoPreference } from '../../utils/mercadopago';

interface MercadoPagoInfoProps {
  settings: PaymentSettings['mercadoPago'];
  cart: CartItem[];
  customerInfo: CustomerInfo;
}

export const MercadoPagoInfo: React.FC<MercadoPagoInfoProps> = ({ 
  settings,
  cart,
  customerInfo
}) => {
  const isConfigured = settings.link && settings.username;

  if (!isConfigured) {
    return (
      <div className="flex items-center gap-2 text-yellow-600">
        <AlertCircle className="w-5 h-5" />
        <p>La información de Mercado Pago no está configurada</p>
      </div>
    );
  }

  // Generate dynamic payment link
  const { paymentUrl } = generateMercadoPagoPreference(
    cart,
    customerInfo,
    settings.link
  );

  return (
    <div className="space-y-4">
      {settings.qrCode && (
        <div className="flex justify-center">
          <img
            src={settings.qrCode}
            alt="Mercado Pago QR"
            className="w-48 h-48"
          />
        </div>
      )}
      
      <div>
        <p className="text-sm font-medium text-gray-700">Usuario</p>
        <p className="text-base">{settings.username}</p>
      </div>

      <CopyableField
        label="Link de pago para tu pedido"
        value={paymentUrl}
        isLink
      />

      <p className="text-sm text-gray-500 mt-2">
        Este link de pago es único para tu pedido. Al hacer clic serás redirigido a Mercado Pago para completar la transacción.
      </p>
    </div>
  );
};