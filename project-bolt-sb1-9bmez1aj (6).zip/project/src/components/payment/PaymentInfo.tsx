import React from 'react';
import { QrCode } from 'lucide-react';
import { useStore } from '../../store/useStore';
import { PaymentMethod, CartItem, CustomerInfo } from '../../types';
import { TransferInfo } from './TransferInfo';
import { MercadoPagoInfo } from './MercadoPagoInfo';

interface PaymentInfoProps {
  method: PaymentMethod;
  onClose: () => void;
  cart: CartItem[];
  customerInfo: CustomerInfo;
}

export const PaymentInfo: React.FC<PaymentInfoProps> = ({
  method,
  onClose,
  cart,
  customerInfo
}) => {
  const { paymentSettings } = useStore();

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg p-6 w-full max-w-md">
        <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
          {method === 'transfer' ? (
            <>Información de Transferencia</>
          ) : (
            <>
              <QrCode className="w-6 h-6" />
              Mercado Pago
            </>
          )}
        </h3>

        {method === 'transfer' ? (
          <TransferInfo settings={paymentSettings.transfer} />
        ) : (
          <MercadoPagoInfo 
            settings={paymentSettings.mercadoPago}
            cart={cart}
            customerInfo={customerInfo}
          />
        )}

        <div className="mt-6 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200"
          >
            Cerrar
          </button>
        </div>
      </div>
    </div>
  );
};