import React, { useState } from 'react';
import { CartItem, CustomerInfo, PaymentMethod } from '../../types';
import { PaymentInfo } from './PaymentInfo';
import { PaymentConfirmationDialog } from './PaymentConfirmationDialog';

interface PaymentFlowProps {
  cart: CartItem[];
  customerInfo: CustomerInfo;
  paymentMethod: PaymentMethod;
  onComplete: () => void;
  onCancel: () => void;
}

export const PaymentFlow: React.FC<PaymentFlowProps> = ({
  cart,
  customerInfo,
  paymentMethod,
  onComplete,
  onCancel,
}) => {
  const [step, setStep] = useState<'info' | 'confirmation'>(
    paymentMethod === 'cash' ? 'confirmation' : 'info'
  );

  const handlePaymentInfoClose = () => {
    setStep('confirmation');
  };

  const handleConfirmationComplete = () => {
    onComplete();
  };

  return (
    <>
      {step === 'info' && (
        <PaymentInfo
          method={paymentMethod}
          onClose={handlePaymentInfoClose}
          cart={cart}
          customerInfo={customerInfo}
        />
      )}

      {step === 'confirmation' && (
        <PaymentConfirmationDialog
          cart={cart}
          customerInfo={customerInfo}
          paymentMethod={paymentMethod}
          onClose={handleConfirmationComplete}
        />
      )}
    </>
  );
};