import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Image } from './Image';

interface ProductImageProps {
  primaryImage: string;
  secondaryImage?: string;
  alt: string;
}

export const ProductImage: React.FC<ProductImageProps> = ({
  primaryImage,
  secondaryImage,
  alt,
}) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div
      className="relative aspect-square overflow-hidden"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <AnimatePresence initial={false} mode="wait">
        <motion.div
          key={isHovered && secondaryImage ? 'secondary' : 'primary'}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
          className="absolute inset-0"
        >
          <Image
            src={isHovered && secondaryImage ? secondaryImage : primaryImage}
            alt={alt}
            aspectRatio="square"
            className="w-full h-full object-contain"
          />
        </motion.div>
      </AnimatePresence>
    </div>
  );
};