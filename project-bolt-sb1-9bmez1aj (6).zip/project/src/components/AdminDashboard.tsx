import React from 'react';
import { useStore } from '../store/useStore';
import { AdminStats } from './AdminStats';
import { TopProducts } from './dashboard/TopProducts';
import { RecentSales } from './dashboard/RecentSales';
import { CustomerOverview } from './dashboard/CustomerOverview';
import { SalesChart } from './dashboard/SalesChart';

export const AdminDashboard: React.FC = () => {
  const products = useStore((state) => state.products);

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900">Panel de Administración</h1>
          <p className="mt-1 text-sm text-gray-500">
            Gestiona tu catálogo y monitorea las estadísticas de tu tienda
          </p>
        </div>

        {/* Stats Overview */}
        <AdminStats products={products} />
        
        {/* Main Dashboard Grid */}
        <div className="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Sales Chart */}
          <div className="bg-white rounded-lg shadow p-6">
            <SalesChart products={products} />
          </div>

          {/* Top Products */}
          <div className="bg-white rounded-lg shadow p-6">
            <TopProducts products={products} />
          </div>

          {/* Recent Sales */}
          <div className="bg-white rounded-lg shadow p-6">
            <RecentSales products={products} />
          </div>

          {/* Customer Overview */}
          <div className="bg-white rounded-lg shadow p-6">
            <CustomerOverview products={products} />
          </div>
        </div>
      </div>
    </div>
  );
};