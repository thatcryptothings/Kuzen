import React from 'react';
import { X } from 'lucide-react';
import { useStore } from '../store/useStore';
import { ImageUploader } from './ImageUploader';

interface ImageManagerProps {
  onClose: () => void;
}

export const ImageManager: React.FC<ImageManagerProps> = ({ onClose }) => {
  const { updateHeaderImage, updateCategoryImage, updateCarouselImages } = useStore();

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg w-full max-w-4xl max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center p-6 border-b">
          <h2 className="text-xl font-semibold">Gestionar Imágenes</h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            <X className="w-6 h-6" />
          </button>
        </div>
        
        <div className="p-6 space-y-8">
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Imagen de Encabezado</h3>
            <ImageUploader
              onImageSelect={(file) => {
                const reader = new FileReader();
                reader.onload = (e) => {
                  updateHeaderImage(e.target?.result as string);
                };
                reader.readAsDataURL(file);
              }}
              label="Cambiar Imagen de Encabezado"
            />
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Imágenes de Categorías</h3>
            <ImageUploader
              onImageSelect={(file) => {
                const reader = new FileReader();
                reader.onload = (e) => {
                  updateCategoryImage('default', e.target?.result as string);
                };
                reader.readAsDataURL(file);
              }}
              label="Cambiar Imagen de Categoría"
            />
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Imágenes del Carrusel</h3>
            <ImageUploader
              onImageSelect={(file) => {
                const reader = new FileReader();
                reader.onload = (e) => {
                  updateCarouselImages([e.target?.result as string]);
                };
                reader.readAsDataURL(file);
              }}
              label="Agregar Imagen al Carrusel"
            />
          </div>
        </div>
      </div>
    </div>
  );
};