import React from 'react';
import { useStore } from '../store/useStore';
import { CustomerList } from './dashboard/CustomerList';
import { CustomerStats } from './dashboard/CustomerStats';

export const CustomerDashboard: React.FC = () => {
  const { customers, products } = useStore();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Información de Clientes</h1>
        <p className="mt-1 text-sm text-gray-500">
          Gestiona y visualiza la información de tus clientes
        </p>
      </div>

      {/* Customer Statistics */}
      <div className="mb-8">
        <CustomerStats customers={customers} products={products} />
      </div>

      {/* Customer List */}
      <CustomerList customers={customers} />
    </div>
  );
};