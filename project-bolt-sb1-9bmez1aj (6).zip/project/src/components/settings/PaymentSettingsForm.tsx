import React from 'react';
import { useStore } from '../../store/useStore';

export const PaymentSettingsForm: React.FC = () => {
  const { paymentSettings, updatePaymentSettings } = useStore();
  const [formData, setFormData] = React.useState(paymentSettings);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updatePaymentSettings(formData);
    alert('Configuración de pagos actualizada');
  };

  const handleChange = (section: 'transfer' | 'mercadoPago', field: string, value: string) => {
    setFormData({
      ...formData,
      [section]: {
        ...formData[section],
        [field]: value
      }
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-semibold mb-4">Transferencia Bancaria</h3>
        <div className="grid grid-cols-1 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Banco
            </label>
            <input
              type="text"
              value={formData.transfer.bankName}
              onChange={(e) => handleChange('transfer', 'bankName', e.target.value)}
              className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Nombre del banco"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Titular de la Cuenta
            </label>
            <input
              type="text"
              value={formData.transfer.accountHolder}
              onChange={(e) => handleChange('transfer', 'accountHolder', e.target.value)}
              className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Nombre del titular"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Número de Cuenta
            </label>
            <input
              type="text"
              value={formData.transfer.accountNumber}
              onChange={(e) => handleChange('transfer', 'accountNumber', e.target.value)}
              className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Número de cuenta"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              CBU
            </label>
            <input
              type="text"
              value={formData.transfer.cbu}
              onChange={(e) => handleChange('transfer', 'cbu', e.target.value)}
              className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="CBU"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Alias
            </label>
            <input
              type="text"
              value={formData.transfer.alias}
              onChange={(e) => handleChange('transfer', 'alias', e.target.value)}
              className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Alias"
            />
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-semibold mb-4">Mercado Pago</h3>
        <div className="grid grid-cols-1 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Link de Pago
            </label>
            <input
              type="url"
              value={formData.mercadoPago.link}
              onChange={(e) => handleChange('mercadoPago', 'link', e.target.value)}
              className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="https://link.mercadopago.com.ar/..."
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              URL del Código QR
            </label>
            <input
              type="url"
              value={formData.mercadoPago.qrCode}
              onChange={(e) => handleChange('mercadoPago', 'qrCode', e.target.value)}
              className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="URL de la imagen del código QR"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Usuario de Mercado Pago
            </label>
            <input
              type="text"
              value={formData.mercadoPago.username}
              onChange={(e) => handleChange('mercadoPago', 'username', e.target.value)}
              className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="@usuario"
            />
          </div>
        </div>
      </div>

      <div className="flex justify-end">
        <button
          type="submit"
          className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
        >
          Guardar Configuración
        </button>
      </div>
    </form>
  );
};