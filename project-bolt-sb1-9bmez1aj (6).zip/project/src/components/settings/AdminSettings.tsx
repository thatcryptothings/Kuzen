import React from 'react';
import { Settings } from 'lucide-react';
import { PaymentSettingsForm } from './PaymentSettingsForm';
import { SalesRepManager } from './SalesRepManager';

export const AdminSettings: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <div className="flex items-center gap-3">
          <Settings className="w-6 h-6 text-gray-600" />
          <h1 className="text-2xl font-bold text-gray-900">Configuración</h1>
        </div>
        <p className="mt-1 text-sm text-gray-500">
          Administra la configuración de tu tienda
        </p>
      </div>

      <div className="space-y-8">
        <PaymentSettingsForm />
        <SalesRepManager />
      </div>
    </div>
  );
};