import React, { useState } from 'react';
import { Plus, X, UserCheck, UserX, Phone, Mail, Edit2 } from 'lucide-react';
import { useStore } from '../../store/useStore';
import { SalesRep } from '../../types';

export const SalesRepManager: React.FC = () => {
  const { salesReps, updateSalesReps } = useStore();
  const [editingRep, setEditingRep] = useState<SalesRep | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
  });
  const [error, setError] = useState('');

  const resetForm = () => {
    setFormData({ name: '', email: '', phone: '' });
    setEditingRep(null);
    setError('');
  };

  const validateForm = () => {
    if (!formData.name.trim()) {
      setError('Por favor ingrese un nombre');
      return false;
    }

    if (!formData.email.trim()) {
      setError('Por favor ingrese un email');
      return false;
    }

    if (!formData.phone.trim()) {
      setError('Por favor ingrese un número de teléfono');
      return false;
    }

    // Basic email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      setError('Por favor ingrese un email válido');
      return false;
    }

    return true;
  };

  const handleSubmit = () => {
    if (!validateForm()) return;

    if (editingRep) {
      // Update existing rep
      const updatedReps = salesReps.map(rep =>
        rep.id === editingRep.id
          ? { ...rep, ...formData }
          : rep
      );
      updateSalesReps(updatedReps);
    } else {
      // Add new rep
      const newRep: SalesRep = {
        id: Date.now().toString(),
        ...formData,
        active: true,
        totalSales: 0,
      };
      updateSalesReps([...salesReps, newRep]);
    }

    resetForm();
  };

  const handleEdit = (rep: SalesRep) => {
    setEditingRep(rep);
    setFormData({
      name: rep.name,
      email: rep.email || '',
      phone: rep.phone || '',
    });
  };

  const toggleRepStatus = (repId: string) => {
    const updatedReps = salesReps.map(rep =>
      rep.id === repId ? { ...rep, active: !rep.active } : rep
    );
    updateSalesReps(updatedReps);
  };

  const deleteRep = (repId: string) => {
    if (confirm('¿Estás seguro de que deseas eliminar esta vendedora?')) {
      const updatedReps = salesReps.filter(rep => rep.id !== repId);
      updateSalesReps(updatedReps);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h3 className="text-lg font-semibold mb-4">
        {editingRep ? 'Editar Vendedora' : 'Agregar Nueva Vendedora'}
      </h3>
      
      <div className="space-y-6">
        {/* Form */}
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Nombre
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => {
                  setFormData({ ...formData, name: e.target.value });
                  setError('');
                }}
                placeholder="Nombre completo"
                className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Email
              </label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => {
                  setFormData({ ...formData, email: e.target.value });
                  setError('');
                }}
                placeholder="correo@ejemplo.com"
                className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                WhatsApp
              </label>
              <input
                type="tel"
                value={formData.phone}
                onChange={(e) => {
                  setFormData({ ...formData, phone: e.target.value });
                  setError('');
                }}
                placeholder="Número con código de país"
                className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          {error && <p className="text-sm text-red-600">{error}</p>}

          <div className="flex justify-end gap-2">
            {editingRep && (
              <button
                onClick={resetForm}
                className="px-4 py-2 border rounded-lg hover:bg-gray-50"
              >
                Cancelar
              </button>
            )}
            <button
              onClick={handleSubmit}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              {editingRep ? 'Guardar Cambios' : 'Agregar Vendedora'}
            </button>
          </div>
        </div>

        {/* Sales reps list */}
        <div className="space-y-2">
          <h4 className="font-medium text-gray-900">Vendedoras Registradas</h4>
          {salesReps.map((rep) => (
            <div
              key={rep.id}
              className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
            >
              <div className="flex items-center gap-4">
                {rep.active ? (
                  <UserCheck className="w-5 h-5 text-green-600" />
                ) : (
                  <UserX className="w-5 h-5 text-red-600" />
                )}
                <div>
                  <span className={`block font-medium ${rep.active ? 'text-gray-900' : 'text-gray-500'}`}>
                    {rep.name}
                  </span>
                  <div className="flex items-center gap-4 mt-1">
                    <span className="text-sm text-gray-500 flex items-center gap-1">
                      <Mail className="w-3 h-3" />
                      {rep.email}
                    </span>
                    <span className="text-sm text-gray-500 flex items-center gap-1">
                      <Phone className="w-3 h-3" />
                      {rep.phone}
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleEdit(rep)}
                  className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg"
                  title="Editar vendedora"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => toggleRepStatus(rep.id)}
                  className={`px-3 py-1 rounded-lg text-sm ${
                    rep.active
                      ? 'bg-red-100 text-red-700 hover:bg-red-200'
                      : 'bg-green-100 text-green-700 hover:bg-green-200'
                  }`}
                >
                  {rep.active ? 'Desactivar' : 'Activar'}
                </button>
                <button
                  onClick={() => deleteRep(rep.id)}
                  className="p-2 text-gray-500 hover:text-red-600 rounded-lg hover:bg-gray-200"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};