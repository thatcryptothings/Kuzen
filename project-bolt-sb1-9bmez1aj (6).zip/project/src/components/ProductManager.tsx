import React, { useState } from 'react';
import { Plus, Search, Eye, EyeOff } from 'lucide-react';
import { Product } from '../types';
import { useStore } from '../store/useStore';
import { ProductForm } from './ProductForm';
import { ProductTable } from './ProductTable';
import { Tabs } from './common/Tabs';

export const ProductManager: React.FC = () => {
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'visible' | 'hidden'>('visible');
  
  const { products, visibleProducts, hiddenProducts, addProduct, updateProduct } = useStore();

  const filteredProducts = (activeTab === 'visible' ? visibleProducts : hiddenProducts)
    .filter(p => 
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.description.toLowerCase().includes(searchQuery.toLowerCase())
    );

  const handleAddProduct = (newProduct: Product) => {
    addProduct(newProduct);
    setShowForm(false);
  };

  const handleEditProduct = (updatedProduct: Product) => {
    updateProduct(updatedProduct.id, updatedProduct);
    setEditingProduct(null);
  };

  const tabs = [
    {
      id: 'visible',
      label: (
        <div className="flex items-center gap-2">
          <Eye className="w-4 h-4" />
          <span>Productos Visibles ({visibleProducts.length})</span>
        </div>
      )
    },
    {
      id: 'hidden',
      label: (
        <div className="flex items-center gap-2">
          <EyeOff className="w-4 h-4" />
          <span>Productos Ocultos ({hiddenProducts.length})</span>
        </div>
      )
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="bg-white rounded-lg shadow">
        <div className="p-4 sm:p-6 border-b border-gray-200">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <h2 className="text-xl font-bold text-gray-900">Gestión de Productos</h2>
              <p className="mt-1 text-sm text-gray-500">
                Administra tu catálogo de productos
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto">
              <div className="relative flex-1 sm:flex-none">
                <input
                  type="text"
                  placeholder="Buscar productos..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 text-sm border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              </div>
              <button
                onClick={() => setShowForm(true)}
                className="flex items-center justify-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors w-full sm:w-auto"
              >
                <Plus className="w-5 h-5" />
                <span>Agregar Producto</span>
              </button>
            </div>
          </div>
        </div>

        <div className="border-b border-gray-200">
          <Tabs
            tabs={tabs}
            activeTab={activeTab}
            onChange={(tab) => setActiveTab(tab as 'visible' | 'hidden')}
          />
        </div>

        <ProductTable 
          products={filteredProducts}
          onEdit={setEditingProduct}
        />
      </div>

      {(showForm || editingProduct) && (
        <ProductForm
          product={editingProduct}
          onSubmit={editingProduct ? handleEditProduct : handleAddProduct}
          onCancel={() => {
            setShowForm(false);
            setEditingProduct(null);
          }}
        />
      )}
    </div>
  );
};