import React from 'react';
import { Copy, QrCode, AlertCircle } from 'lucide-react';
import { useStore } from '../store/useStore';
import { PaymentMethod } from '../types';

interface PaymentInfoProps {
  method: PaymentMethod;
  onClose: () => void;
}

export const PaymentInfo: React.FC<PaymentInfoProps> = ({ method, onClose }) => {
  const { paymentSettings } = useStore();
  
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    alert('Copiado al portapapeles');
  };

  const isTransferConfigured = 
    paymentSettings.transfer.bankName &&
    paymentSettings.transfer.accountHolder &&
    paymentSettings.transfer.cbu;

  const isMercadoPagoConfigured = 
    paymentSettings.mercadoPago.link &&
    paymentSettings.mercadoPago.username;

  const renderTransferInfo = () => {
    if (!isTransferConfigured) {
      return (
        <div className="flex items-center gap-2 text-yellow-600">
          <AlertCircle className="w-5 h-5" />
          <p>La información de transferencia no está configurada</p>
        </div>
      );
    }

    return (
      <div className="space-y-4">
        <div>
          <p className="text-sm font-medium text-gray-700">Banco</p>
          <p className="text-base">{paymentSettings.transfer.bankName}</p>
        </div>
        
        <div>
          <p className="text-sm font-medium text-gray-700">Titular</p>
          <p className="text-base">{paymentSettings.transfer.accountHolder}</p>
        </div>

        {paymentSettings.transfer.accountNumber && (
          <div>
            <p className="text-sm font-medium text-gray-700">Número de Cuenta</p>
            <div className="flex items-center gap-2">
              <p className="text-base font-mono">{paymentSettings.transfer.accountNumber}</p>
              <button
                onClick={() => copyToClipboard(paymentSettings.transfer.accountNumber)}
                className="p-1 hover:bg-gray-100 rounded"
                title="Copiar al portapapeles"
              >
                <Copy className="w-4 h-4 text-gray-500" />
              </button>
            </div>
          </div>
        )}

        <div>
          <p className="text-sm font-medium text-gray-700">CBU</p>
          <div className="flex items-center gap-2">
            <p className="text-base font-mono break-all">{paymentSettings.transfer.cbu}</p>
            <button
              onClick={() => copyToClipboard(paymentSettings.transfer.cbu)}
              className="p-1 hover:bg-gray-100 rounded flex-shrink-0"
              title="Copiar al portapapeles"
            >
              <Copy className="w-4 h-4 text-gray-500" />
            </button>
          </div>
        </div>

        {paymentSettings.transfer.alias && (
          <div>
            <p className="text-sm font-medium text-gray-700">Alias</p>
            <div className="flex items-center gap-2">
              <p className="text-base font-mono">{paymentSettings.transfer.alias}</p>
              <button
                onClick={() => copyToClipboard(paymentSettings.transfer.alias)}
                className="p-1 hover:bg-gray-100 rounded"
                title="Copiar al portapapeles"
              >
                <Copy className="w-4 h-4 text-gray-500" />
              </button>
            </div>
          </div>
        )}
      </div>
    );
  };

  const renderMercadoPagoInfo = () => {
    if (!isMercadoPagoConfigured) {
      return (
        <div className="flex items-center gap-2 text-yellow-600">
          <AlertCircle className="w-5 h-5" />
          <p>La información de Mercado Pago no está configurada</p>
        </div>
      );
    }

    return (
      <div className="space-y-4">
        {paymentSettings.mercadoPago.qrCode && (
          <div className="flex justify-center">
            <img
              src={paymentSettings.mercadoPago.qrCode}
              alt="Mercado Pago QR"
              className="w-48 h-48"
            />
          </div>
        )}
        
        <div>
          <p className="text-sm font-medium text-gray-700">Usuario</p>
          <p className="text-base">{paymentSettings.mercadoPago.username}</p>
        </div>

        <div>
          <p className="text-sm font-medium text-gray-700">Link de pago</p>
          <div className="flex items-center gap-2">
            <a
              href={paymentSettings.mercadoPago.link}
              target="_blank"
              rel="noopener noreferrer"
              className="text-blue-600 hover:underline truncate flex-1"
            >
              {paymentSettings.mercadoPago.link}
            </a>
            <button
              onClick={() => copyToClipboard(paymentSettings.mercadoPago.link)}
              className="p-1 hover:bg-gray-100 rounded flex-shrink-0"
              title="Copiar al portapapeles"
            >
              <Copy className="w-4 h-4 text-gray-500" />
            </button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg p-6 w-full max-w-md">
        <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
          {method === 'transfer' ? (
            <>Información de Transferencia</>
          ) : (
            <>
              <QrCode className="w-6 h-6" />
              Mercado Pago
            </>
          )}
        </h3>

        {method === 'transfer' ? renderTransferInfo() : renderMercadoPagoInfo()}

        <div className="mt-6 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200"
          >
            Cerrar
          </button>
        </div>
      </div>
    </div>
  );
};