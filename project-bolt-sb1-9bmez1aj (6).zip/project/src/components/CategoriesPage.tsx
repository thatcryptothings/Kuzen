import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../store/useStore';
import { SearchBar } from './SearchBar';
import { PromotionalCarousel } from './PromotionalCarousel';

export const CategoriesPage: React.FC = () => {
  const products = useStore((state) => state.products || []);
  const setSelectedCategory = useStore((state) => state.setSelectedCategory);
  const searchQuery = useStore((state) => state.searchQuery);
  const navigate = useNavigate();

  const categories = [...new Set(products.map((product) => product.category))];

  const handleCategoryClick = (category: string) => {
    setSelectedCategory(category);
    navigate('/products');
  };

  const getCategoryImage = (category: string) => {
    const product = products.find(p => p.category === category);
    return product?.imageUrl || 'https://images.unsplash.com/photo-1556911220-bff31c812dba?w=1600&q=80';
  };

  useEffect(() => {
    if (searchQuery) {
      setSelectedCategory(null);
      navigate('/products');
    }
  }, [searchQuery, navigate, setSelectedCategory]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-8">
      <div className="mb-10 sm:mb-16">
        <SearchBar />
      </div>
      
      <PromotionalCarousel />
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 sm:gap-8 mt-16 sm:mt-20">
        {categories.map((category) => (
          <motion.div
            key={category}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="relative cursor-pointer rounded-lg overflow-hidden shadow-lg aspect-[4/3] sm:aspect-square"
            onClick={() => handleCategoryClick(category)}
          >
            <img
              src={getCategoryImage(category)}
              alt={category}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-black/20 flex items-end p-4">
              <h3 className="text-white font-semibold text-lg">
                {category}
              </h3>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};