import React, { useState } from 'react';
import { Phone } from 'lucide-react';

interface WhatsAppContactInputProps {
  onSubmit: (phoneNumber: string) => void;
  onCancel: () => void;
}

export const WhatsAppContactInput: React.FC<WhatsAppContactInputProps> = ({
  onSubmit,
  onCancel,
}) => {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const cleanNumber = phoneNumber.replace(/\D/g, '');
    if (cleanNumber.length < 10) {
      setError('Por favor, ingrese un número de teléfono válido');
      return;
    }
    
    onSubmit(cleanNumber);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-96 max-w-full mx-4">
        <h3 className="text-lg font-semibold mb-4 flex items-center">
          <Phone className="w-5 h-5 mr-2" />
          Ingrese Número de WhatsApp
        </h3>
        <form onSubmit={handleSubmit}>
          <input
            type="tel"
            value={phoneNumber}
            onChange={(e) => {
              setPhoneNumber(e.target.value);
              setError('');
            }}
            placeholder="Ingrese número de teléfono (con código de país)"
            className="w-full px-4 py-2 border rounded-lg mb-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          {error && <p className="text-red-500 text-sm mb-2">{error}</p>}
          <div className="flex gap-2">
            <button
              type="button"
              onClick={onCancel}
              className="flex-1 px-4 py-2 border rounded-lg hover:bg-gray-100"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
            >
              Enviar Pedido
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};