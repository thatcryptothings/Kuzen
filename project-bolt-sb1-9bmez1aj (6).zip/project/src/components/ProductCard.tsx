import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ShoppingCart } from 'lucide-react';
import { Product } from '../types';
import { useStore } from '../store/useStore';
import { ProductImage } from './ProductImage';
import { ProductActions } from './ProductActions';
import { ProductForm } from './ProductForm';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const [showEditForm, setShowEditForm] = useState(false);
  const addToCart = useStore((state) => state.addToCart);
  const { products, updateProducts } = useStore();
  const secondaryImage = product.images?.[0];

  const handleEdit = () => {
    setShowEditForm(true);
  };

  const handleDelete = () => {
    updateProducts(products.filter(p => p.id !== product.id));
  };

  const handleUpdate = (updatedProduct: Product) => {
    updateProducts(products.map(p => p.id === updatedProduct.id ? updatedProduct : p));
    setShowEditForm(false);
  };

  const isAdmin = localStorage.getItem('isAdmin') === 'true';

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative flex flex-col bg-white rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow duration-300"
      >
        {isAdmin && (
          <ProductActions
            onEdit={handleEdit}
            onDelete={handleDelete}
          />
        )}

        <ProductImage
          primaryImage={product.imageUrl}
          secondaryImage={secondaryImage}
          alt={product.name}
        />

        <div className="p-3 sm:p-4 flex flex-col gap-1 sm:gap-2">
          <p className="text-base sm:text-lg font-semibold text-black">
            ${product.price.toFixed(2)}
          </p>
          <h3 className="text-xs sm:text-sm text-gray-600 line-clamp-2">{product.name}</h3>
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => addToCart(product)}
            className="w-full bg-black text-white py-2 sm:py-2.5 text-xs sm:text-sm font-medium rounded-lg hover:bg-gray-900 transition-colors flex items-center justify-center gap-1 sm:gap-2"
          >
            <ShoppingCart className="w-3 h-3 sm:w-4 sm:h-4" />
            Agregar
          </motion.button>
        </div>
      </motion.div>

      {showEditForm && (
        <ProductForm
          product={product}
          onSubmit={handleUpdate}
          onCancel={() => setShowEditForm(false)}
        />
      )}
    </>
  );
};