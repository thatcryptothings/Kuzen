import React from 'react';
import { Edit2, Trash2 } from 'lucide-react';
import { motion } from 'framer-motion';

interface ProductActionsProps {
  onEdit: () => void;
  onDelete: () => void;
}

export const ProductActions: React.FC<ProductActionsProps> = ({ onEdit, onDelete }) => {
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="absolute top-2 right-2 flex gap-2"
    >
      <button
        onClick={onEdit}
        className="p-2 bg-white rounded-full shadow-lg hover:bg-blue-50 transition-colors"
      >
        <Edit2 className="w-4 h-4 text-blue-600" />
      </button>
      <button
        onClick={(e) => {
          e.stopPropagation();
          if (window.confirm('¿Estás seguro de que deseas eliminar este producto?')) {
            onDelete();
          }
        }}
        className="p-2 bg-white rounded-full shadow-lg hover:bg-red-50 transition-colors"
      >
        <Trash2 className="w-4 h-4 text-red-600" />
      </button>
    </motion.div>
  );
};