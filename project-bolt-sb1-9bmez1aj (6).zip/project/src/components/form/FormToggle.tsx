import React from 'react';
import { motion } from 'framer-motion';

interface FormToggleProps {
  label: string;
  checked: boolean;
  onChange: (checked: boolean) => void;
  description?: string;
}

export const FormToggle: React.FC<FormToggleProps> = ({
  label,
  checked,
  onChange,
  description,
}) => {
  return (
    <div className="flex flex-col gap-1">
      <label className="block text-sm font-medium text-gray-700">
        {label}
      </label>
      <div className="flex items-center">
        <button
          type="button"
          role="switch"
          aria-checked={checked}
          onClick={() => onChange(!checked)}
          className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 ${
            checked ? 'bg-blue-600' : 'bg-gray-200'
          }`}
        >
          <motion.span
            layout
            className="inline-block h-4 w-4 transform rounded-full bg-white transition-transform"
            animate={{
              x: checked ? 28 : 4,
            }}
          />
        </button>
        {description && (
          <span className="ml-3 text-sm text-gray-500">{description}</span>
        )}
      </div>
    </div>
  );
};