import React from 'react';
import { Users, TrendingUp, Star } from 'lucide-react';
import { useSalesReps } from '../../hooks/useSalesReps';

export const SalesRepStats: React.FC = () => {
  const { salesReps } = useSalesReps();
  const activeReps = salesReps.filter(rep => rep.active).length;
  const totalSales = salesReps.reduce((sum, rep) => sum + (rep.totalSales || 0), 0);
  const avgSalesPerRep = activeReps ? Math.round(totalSales / activeReps) : 0;

  const stats = [
    {
      name: 'Vendedoras Activas',
      value: activeReps,
      icon: Users,
      color: 'bg-blue-500'
    },
    {
      name: 'Ventas Totales',
      value: totalSales,
      icon: TrendingUp,
      color: 'bg-green-500'
    },
    {
      name: 'Promedio por Vendedora',
      value: avgSalesPerRep,
      icon: Star,
      color: 'bg-purple-500'
    }
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
      {stats.map((stat) => (
        <div
          key={stat.name}
          className="bg-white rounded-lg shadow p-4 sm:p-6 flex items-center"
        >
          <div className={`${stat.color} p-3 rounded-lg`}>
            <stat.icon className="w-5 h-5 text-white" />
          </div>
          <div className="ml-4">
            <p className="text-sm font-medium text-gray-500">{stat.name}</p>
            <p className="text-xl font-semibold text-gray-900">{stat.value}</p>
          </div>
        </div>
      ))}
    </div>
  );
};