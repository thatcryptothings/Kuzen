import React, { useState } from 'react';
import { SalesRep } from '../../types';
import { useSalesReps } from '../../hooks/useSalesReps';
import { FormInput } from '../form/FormInput';

interface SalesRepFormProps {
  salesRep?: SalesRep;
  onSuccess: () => void;
  onCancel: () => void;
}

export const SalesRepForm: React.FC<SalesRepFormProps> = ({
  salesRep,
  onSuccess,
  onCancel
}) => {
  const { addSalesRep, updateSalesRep } = useSalesReps();
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const [formData, setFormData] = useState({
    name: salesRep?.name || '',
    email: salesRep?.email || '',
    phone: salesRep?.phone || ''
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsSubmitting(true);

    try {
      if (salesRep) {
        await updateSalesRep(salesRep.id, formData);
      } else {
        await addSalesRep(formData);
      }
      onSuccess();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error al guardar los datos');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <FormInput
        label="Nombre"
        value={formData.name}
        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
        required
        disabled={isSubmitting}
      />

      <FormInput
        label="Email"
        type="email"
        value={formData.email}
        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
        required
        disabled={isSubmitting}
      />

      <FormInput
        label="Teléfono"
        type="tel"
        value={formData.phone}
        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
        placeholder="+54 9 11 1234-5678"
        required
        disabled={isSubmitting}
      />

      {error && (
        <p className="text-sm text-red-600">{error}</p>
      )}

      <div className="flex justify-end gap-2">
        <button
          type="button"
          onClick={onCancel}
          disabled={isSubmitting}
          className="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200"
        >
          Cancelar
        </button>
        <button
          type="submit"
          disabled={isSubmitting}
          className="px-4 py-2 text-white bg-blue-600 rounded-lg hover:bg-blue-700 disabled:opacity-50"
        >
          {isSubmitting ? 'Guardando...' : salesRep ? 'Actualizar' : 'Agregar'}
        </button>
      </div>
    </form>
  );
};