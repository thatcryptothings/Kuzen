import React from 'react';
import { Mail, Phone, UserCheck, UserX, Edit2, Trash2 } from 'lucide-react';
import { SalesRep } from '../../types';
import { useSalesReps } from '../../hooks/useSalesReps';

interface SalesRepListProps {
  onEdit: (rep: SalesRep) => void;
  className?: string;
}

export const SalesRepList: React.FC<SalesRepListProps> = ({ onEdit, className }) => {
  const { salesReps, toggleSalesRepStatus, deleteSalesRep } = useSalesReps();

  const handleDelete = (rep: SalesRep) => {
    if (window.confirm(`¿Estás seguro de que deseas eliminar a ${rep.name}?`)) {
      deleteSalesRep(rep.id);
    }
  };

  return (
    <div className="overflow-x-auto">
      <div className="inline-block min-w-full align-middle">
        <div className={className}>
          {salesReps.map((rep) => (
            <div
              key={rep.id}
              className="flex flex-col sm:flex-row sm:items-center justify-between p-4 sm:p-6 hover:bg-gray-50 gap-4"
            >
              <div className="flex-1">
                <div className="flex items-center mb-2 sm:mb-0">
                  {rep.active ? (
                    <UserCheck className="w-5 h-5 text-green-500 mr-3" />
                  ) : (
                    <UserX className="w-5 h-5 text-red-500 mr-3" />
                  )}
                  <div>
                    <h3 className="text-sm font-medium text-gray-900">
                      {rep.name}
                    </h3>
                    <div className="mt-1 flex flex-col sm:flex-row gap-2 sm:gap-4 text-sm text-gray-500">
                      <span className="flex items-center gap-1">
                        <Mail className="w-4 h-4" />
                        {rep.email}
                      </span>
                      <span className="flex items-center gap-1">
                        <Phone className="w-4 h-4" />
                        {rep.phone}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 self-end sm:self-center">
                <button
                  onClick={() => onEdit(rep)}
                  className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg"
                  title="Editar vendedora"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => toggleSalesRepStatus(rep.id)}
                  className={`px-3 py-1 rounded-lg text-sm ${
                    rep.active
                      ? 'bg-red-100 text-red-700 hover:bg-red-200'
                      : 'bg-green-100 text-green-700 hover:bg-green-200'
                  }`}
                >
                  {rep.active ? 'Desactivar' : 'Activar'}
                </button>
                <button
                  onClick={() => handleDelete(rep)}
                  className="p-2 text-red-600 hover:bg-red-50 rounded-lg"
                  title="Eliminar vendedora"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};