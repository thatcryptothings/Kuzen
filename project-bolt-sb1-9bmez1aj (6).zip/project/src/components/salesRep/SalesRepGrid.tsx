import React from 'react';
import { SalesRep } from '../../types';
import { SalesRepCard } from './SalesRepCard';
import { useSalesReps } from '../../hooks/useSalesReps';

interface SalesRepGridProps {
  onEdit: (rep: SalesRep) => void;
}

export const SalesRepGrid: React.FC<SalesRepGridProps> = ({ onEdit }) => {
  const { salesReps, toggleSalesRepStatus, deleteSalesRep } = useSalesReps();

  const handleDelete = (rep: SalesRep) => {
    if (window.confirm(`¿Estás seguro de que deseas eliminar a ${rep.name}?`)) {
      deleteSalesRep(rep.id);
    }
  };

  if (salesReps.length === 0) {
    return (
      <div className="text-center py-12 bg-white rounded-lg shadow">
        <p className="text-gray-500">No hay vendedoras registradas</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {salesReps.map((rep) => (
        <SalesRepCard
          key={rep.id}
          rep={rep}
          onEdit={onEdit}
          onToggleStatus={toggleSalesRepStatus}
          onDelete={handleDelete}
        />
      ))}
    </div>
  );
};