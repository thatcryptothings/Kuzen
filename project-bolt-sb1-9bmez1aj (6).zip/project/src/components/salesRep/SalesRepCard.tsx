import React from 'react';
import { Mail, Phone, UserCheck, UserX, Edit2, Trash2, TrendingUp } from 'lucide-react';
import { SalesRep } from '../../types';
import { motion } from 'framer-motion';

interface SalesRepCardProps {
  rep: SalesRep;
  onEdit: (rep: SalesRep) => void;
  onToggleStatus: (id: string) => void;
  onDelete: (rep: SalesRep) => void;
}

export const SalesRepCard: React.FC<SalesRepCardProps> = ({
  rep,
  onEdit,
  onToggleStatus,
  onDelete,
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-lg shadow-md overflow-hidden"
    >
      {/* Card Header */}
      <div className="p-4 bg-gradient-to-r from-blue-50 to-purple-50 border-b">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            {rep.active ? (
              <div className="bg-green-100 p-2 rounded-full">
                <UserCheck className="w-5 h-5 text-green-600" />
              </div>
            ) : (
              <div className="bg-red-100 p-2 rounded-full">
                <UserX className="w-5 h-5 text-red-600" />
              </div>
            )}
            <div>
              <h3 className="font-semibold text-gray-900">{rep.name}</h3>
              <span className={`text-sm ${rep.active ? 'text-green-600' : 'text-red-600'}`}>
                {rep.active ? 'Activa' : 'Inactiva'}
              </span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-blue-600" />
            <span className="text-sm font-medium text-blue-600">
              {rep.totalSales || 0} ventas
            </span>
          </div>
        </div>
      </div>

      {/* Card Content */}
      <div className="p-4 space-y-3">
        <div className="flex items-center gap-2 text-gray-600">
          <Mail className="w-4 h-4" />
          <span className="text-sm">{rep.email}</span>
        </div>
        <div className="flex items-center gap-2 text-gray-600">
          <Phone className="w-4 h-4" />
          <span className="text-sm">{rep.phone}</span>
        </div>
      </div>

      {/* Card Actions */}
      <div className="px-4 py-3 bg-gray-50 border-t flex justify-end gap-2">
        <button
          onClick={() => onEdit(rep)}
          className="px-3 py-1.5 text-blue-600 hover:bg-blue-50 rounded-md flex items-center gap-1 transition-colors"
        >
          <Edit2 className="w-4 h-4" />
          <span className="text-sm">Editar</span>
        </button>
        <button
          onClick={() => onToggleStatus(rep.id)}
          className={`px-3 py-1.5 rounded-md flex items-center gap-1 transition-colors ${
            rep.active
              ? 'text-red-600 hover:bg-red-50'
              : 'text-green-600 hover:bg-green-50'
          }`}
        >
          {rep.active ? <UserX className="w-4 h-4" /> : <UserCheck className="w-4 h-4" />}
          <span className="text-sm">{rep.active ? 'Desactivar' : 'Activar'}</span>
        </button>
        <button
          onClick={() => onDelete(rep)}
          className="px-3 py-1.5 text-red-600 hover:bg-red-50 rounded-md flex items-center gap-1 transition-colors"
        >
          <Trash2 className="w-4 h-4" />
          <span className="text-sm">Eliminar</span>
        </button>
      </div>
    </motion.div>
  );
};