import React, { useState } from 'react';
import { Plus, Users, Search } from 'lucide-react';
import { SalesRep } from '../../types';
import { SalesRepForm } from './SalesRepForm';
import { SalesRepGrid } from './SalesRepGrid';
import { SalesRepStats } from './SalesRepStats';

export const SalesRepManager: React.FC = () => {
  const [selectedRep, setSelectedRep] = useState<SalesRep | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const handleSuccess = () => {
    setShowForm(false);
    setSelectedRep(null);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-4">
          <Users className="w-6 h-6 text-gray-600" />
          <h1 className="text-2xl font-bold text-gray-900">Vendedoras</h1>
        </div>

        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div className="relative flex-1 max-w-md">
            <input
              type="text"
              placeholder="Buscar vendedoras..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 text-sm border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          </div>
          <button
            onClick={() => setShowForm(true)}
            className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Plus className="w-5 h-5 mr-2" />
            Agregar Vendedora
          </button>
        </div>
      </div>

      <div className="space-y-8">
        <SalesRepStats />
        <SalesRepGrid onEdit={setSelectedRep} />
      </div>

      {(showForm || selectedRep) && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <h3 className="text-lg font-semibold mb-4">
              {selectedRep ? 'Editar Vendedora' : 'Nueva Vendedora'}
            </h3>
            <SalesRepForm
              salesRep={selectedRep}
              onSuccess={handleSuccess}
              onCancel={() => {
                setShowForm(false);
                setSelectedRep(null);
              }}
            />
          </div>
        </div>
      )}
    </div>
  );
};