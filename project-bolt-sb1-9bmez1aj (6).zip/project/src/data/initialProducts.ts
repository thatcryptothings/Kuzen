import { Product } from '../types';
import { asadoProducts } from './categories/asado';
import { utensiliosProducts } from './categories/utensilios';
import { ollasProducts } from './categories/ollas';
import { desayunoProducts } from './categories/desayuno';
import { cuchillosProducts } from './categories/cuchillos';
import { vajillaProducts } from './categories/vajilla';
import { hornoProducts } from './categories/horno';
import { cubiertosProducts } from './categories/cubiertos';

export const initialProducts: Product[] = [
  ...asadoProducts,
  ...utensiliosProducts,
  ...ollasProducts,
  ...desayunoProducts,
  ...cuchillosProducts,
  ...vajillaProducts,
  ...hornoProducts,
  ...cubiertosProducts
];