import { SalesRep } from '../types';

export const initialSalesReps: SalesRep[] = [
  {
    id: '1',
    name: 'Ana García',
    email: 'ana.garcia@example.com',
    phone: '5491112345678',
    active: true,
    totalSales: 0,
  },
  {
    id: '2',
    name: 'María López',
    email: 'maria.lopez@example.com',
    phone: '5491187654321',
    active: true,
    totalSales: 0,
  },
  {
    id: '3',
    name: 'Laura Martínez',
    email: 'laura.martinez@example.com',
    phone: '5491198765432',
    active: true,
    totalSales: 0,
  },
  {
    id: '4',
    name: 'Carolina Rodríguez',
    email: 'carolina.rodriguez@example.com',
    phone: '5491123456789',
    active: true,
    totalSales: 0,
  },
];