import { Product } from '../../types';

export const asadoProducts: Product[] = [
  {
    id: 'asado-1',
    name: 'Parrilla Hudson Premium',
    description: 'Parrilla de acero inoxidable con regulador de altura y bandeja recolectora',
    price: 89999.99,
    imageUrl: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=1080&h=1080&fit=crop',
    category: 'Asado',
    labels: ['Premium'],
    stock: 15,
    size: {
      value: 100,
      unit: 'cm'
    },
    color: 'Plateado'
  },
  {
    id: 'asado-2',
    name: 'Set Asador Hudson Pro',
    description: 'Set completo de utensilios para asado profesional',
    price: 42999.99,
    imageUrl: 'https://images.unsplash.com/photo-1547150492-da7ff1742941?w=1080&h=1080&fit=crop',
    category: 'Asado',
    labels: ['Professional'],
    stock: 20,
    color: 'Negro'
  },
  {
    id: 'asado-3',
    name: 'Tabla de Asado Hudson',
    description: 'Tabla de madera premium para servir asado',
    price: 15999.99,
    imageUrl: 'https://images.unsplash.com/photo-1579698205916-4d42ddfcd986?w=1080&h=1080&fit=crop',
    category: 'Asado',
    stock: 30,
    color: 'Madera Natural'
  },
  {
    id: 'asado-4',
    name: 'Pinzas Hudson Premium',
    description: 'Pinzas de acero inoxidable para asado con mango ergonómico',
    price: 8999.99,
    imageUrl: 'https://images.unsplash.com/photo-1620177088258-c84147ee601f?w=1080&h=1080&fit=crop',
    category: 'Asado',
    stock: 40,
    color: 'Plateado'
  },
  {
    id: 'asado-5',
    name: 'Cuchillo Asador Hudson',
    description: 'Cuchillo profesional para asado con hoja de acero inoxidable',
    price: 12999.99,
    imageUrl: 'https://images.unsplash.com/photo-1593618997771-c313826e0f8e?w=1080&h=1080&fit=crop',
    category: 'Asado',
    stock: 25,
    color: 'Negro'
  },
  {
    id: 'asado-6',
    name: 'Plancha Hudson Grill',
    description: 'Plancha de hierro fundido para asado',
    price: 29999.99,
    imageUrl: 'https://images.unsplash.com/photo-1598514983318-2f64f8f4796c?w=1080&h=1080&fit=crop',
    category: 'Asado',
    stock: 20,
    color: 'Negro'
  },
  {
    id: 'asado-7',
    name: 'Tenedor Asador Hudson',
    description: 'Tenedor profesional para asado con mango de madera',
    price: 7999.99,
    imageUrl: 'https://images.unsplash.com/photo-1589985270958-a664e6df7618?w=1080&h=1080&fit=crop',
    category: 'Asado',
    stock: 35,
    color: 'Madera'
  }
];