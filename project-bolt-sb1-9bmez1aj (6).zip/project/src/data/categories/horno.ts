import { Product } from '../../types';

export const hornoProducts: Product[] = [
  {
    id: 'horno-1',
    name: 'Molde Hudson Premium',
    description: 'Molde para horno antiadherente',
    price: 19999.99,
    imageUrl: 'https://images.unsplash.com/photo-1621996346565-e3dbc646d9a9?w=1080&h=1080&fit=crop',
    category: 'Horno',
    stock: 30,
    size: {
      value: 30,
      unit: 'cm'
    },
    color: 'Negro'
  },
  {
    id: 'horno-2',
    name: 'Bandeja Hudson Pro',
    description: 'Bandeja para horno de acero inoxidable',
    price: 15999.99,
    imageUrl: 'https://images.unsplash.com/photo-1621996346565-e3dbc646d9a9?w=1080&h=1080&fit=crop',
    category: 'Horno',
    stock: 25,
    size: {
      value: 40,
      unit: 'cm'
    },
    color: 'Plateado'
  },
  {
    id: 'horno-3',
    name: 'Set Repostería Hudson',
    description: 'Set completo de moldes para repostería',
    price: 42999.99,
    imageUrl: 'https://images.unsplash.com/photo-1621996346565-e3dbc646d9a9?w=1080&h=1080&fit=crop',
    category: 'Horno',
    stock: 20,
    color: 'Negro'
  }
];