import { Product } from '../../types';

export const utensiliosProducts: Product[] = [
  {
    id: 'utensilios-1',
    name: 'Set Utensilios Hudson Basic',
    description: 'Set básico de utensilios de cocina con soporte',
    price: 35999.99,
    imageUrl: 'https://images.unsplash.com/photo-1590794056226-79ef3a8147e1?w=1080&h=1080&fit=crop',
    category: 'Utensilios y Más',
    stock: 25,
    color: 'Plateado'
  },
  {
    id: 'utensilios-2',
    name: 'Espátulas Silicona Hudson',
    description: 'Set de espátulas de silicona resistentes al calor',
    price: 18999.99,
    imageUrl: 'https://images.unsplash.com/photo-1585515320310-259814833e62?w=1080&h=1080&fit=crop',
    category: 'Utensilios y Más',
    stock: 30,
    color: 'Negro'
  },
  {
    id: 'utensilios-3',
    name: 'Batidor Profesional Hudson',
    description: 'Batidor de acero inoxidable para uso profesional',
    price: 12999.99,
    imageUrl: 'https://images.unsplash.com/photo-1608163364633-97c1d5d6d23b?w=1080&h=1080&fit=crop',
    category: 'Utensilios y Más',
    stock: 40,
    color: 'Plateado'
  },
  {
    id: 'utensilios-4',
    name: 'Colador Hudson Premium',
    description: 'Colador de acero inoxidable con base estable',
    price: 9999.99,
    imageUrl: 'https://images.unsplash.com/photo-1584736286279-5d85dd51b7e4?w=1080&h=1080&fit=crop',
    category: 'Utensilios y Más',
    stock: 20,
    color: 'Plateado'
  },
  {
    id: 'utensilios-5',
    name: 'Rallador Multiuso Hudson',
    description: 'Rallador profesional con diferentes tipos de corte',
    price: 8499.99,
    imageUrl: 'https://images.unsplash.com/photo-1593096380974-c95c97afa024?w=1080&h=1080&fit=crop',
    category: 'Utensilios y Más',
    stock: 30,
    color: 'Plateado'
  },
  {
    id: 'utensilios-6',
    name: 'Set Medidores Hudson',
    description: 'Set de cucharas y tazas medidoras de acero inoxidable',
    price: 11999.99,
    imageUrl: 'https://images.unsplash.com/photo-1591261730799-ee4e6c2d16d7?w=1080&h=1080&fit=crop',
    category: 'Utensilios y Más',
    stock: 25,
    color: 'Plateado'
  },
  {
    id: 'utensilios-7',
    name: 'Mortero Hudson Stone',
    description: 'Mortero de piedra con pilón para especias',
    price: 14999.99,
    imageUrl: 'https://images.unsplash.com/photo-1593095948071-474c5cc2989d?w=1080&h=1080&fit=crop',
    category: 'Utensilios y Más',
    stock: 15,
    color: 'Gris'
  }
];