import { Product } from '../../types';

export const vajillaProducts: Product[] = [
  {
    id: 'vajilla-1',
    name: 'Set Vajilla Hudson Premium',
    description: 'Set completo de vajilla para 6 personas',
    price: 75999.99,
    imageUrl: 'https://images.unsplash.com/photo-1603199506016-b9a594b593c0?w=1080&h=1080&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1563136006-0ae887835761?w=1080&h=1080&fit=crop'
    ],
    category: 'Vajilla y Cristalería',
    labels: ['Premium'],
    stock: 15,
    color: 'Blanco'
  },
  {
    id: 'vajilla-2',
    name: 'Copas Vino Hudson Crystal',
    description: 'Set de 6 copas de cristal para vino',
    price: 32999.99,
    imageUrl: 'https://images.unsplash.com/photo-1549661786-3cf166d9dcb9?w=1080&h=1080&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1514362453360-8f94243c9996?w=1080&h=1080&fit=crop'
    ],
    category: 'Vajilla y Cristalería',
    stock: 20,
    color: 'Transparente'
  },
  {
    id: 'vajilla-3',
    name: 'Platos Hudson Classic',
    description: 'Set de 6 platos planos de porcelana',
    price: 28999.99,
    imageUrl: 'https://images.unsplash.com/photo-1603199506016-b9a594b593c0?w=1080&h=1080&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1563136006-0ae887835761?w=1080&h=1080&fit=crop'
    ],
    category: 'Vajilla y Cristalería',
    stock: 25,
    color: 'Blanco'
  }
];