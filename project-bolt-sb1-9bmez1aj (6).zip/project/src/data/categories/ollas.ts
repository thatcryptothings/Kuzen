import { Product } from '../../types';

export const ollasProducts: Product[] = [
  {
    id: 'ollas-1',
    name: 'Olla Hudson Professional 24cm',
    description: 'Olla de acero inoxidable con tapa de vidrio templado',
    price: 45999.99,
    imageUrl: 'https://images.unsplash.com/photo-1584990347449-a8f1d86dd69c?w=1080&h=1080&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1592156328697-079f6bd49e39?w=1080&h=1080&fit=crop'
    ],
    category: 'Ollas, Sartenes y Jarros',
    labels: ['Premium'],
    stock: 20,
    size: {
      value: 24,
      unit: 'cm'
    },
    color: 'Plateado'
  },
  {
    id: 'ollas-2',
    name: 'Sartén Hudson Chef 28cm',
    description: 'Sartén antiadherente con mango ergonómico',
    price: 32999.99,
    imageUrl: 'https://images.unsplash.com/photo-1593618999088-c5586d6b3995?w=1080&h=1080&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1593618997811-a3c85263429c?w=1080&h=1080&fit=crop'
    ],
    category: 'Ollas, Sartenes y Jarros',
    stock: 25,
    size: {
      value: 28,
      unit: 'cm'
    },
    color: 'Negro'
  },
  {
    id: 'ollas-3',
    name: 'Jarro Hudson Térmico',
    description: 'Jarro térmico de acero inoxidable doble pared',
    price: 15999.99,
    imageUrl: 'https://images.unsplash.com/photo-1577937927133-66ef06acdf18?w=1080&h=1080&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1622440103043-bb0b5dc8d850?w=1080&h=1080&fit=crop'
    ],
    category: 'Ollas, Sartenes y Jarros',
    stock: 30,
    size: {
      value: 500,
      unit: 'cm'
    },
    color: 'Plateado'
  }
];