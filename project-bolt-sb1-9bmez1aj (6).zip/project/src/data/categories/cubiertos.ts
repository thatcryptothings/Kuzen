import { Product } from '../../types';

export const cubiertosProducts: Product[] = [
  {
    id: 'cubiertos-1',
    name: 'Set Cubiertos Hudson Premium',
    description: 'Set de cubiertos completo para 6 personas',
    price: 65999.99,
    imageUrl: 'https://images.unsplash.com/photo-1544829885-75d3c7e9e73e?w=1080&h=1080&fit=crop',
    category: 'Cubiertos',
    labels: ['Premium'],
    stock: 20,
    color: 'Plateado'
  },
  {
    id: 'cubiertos-2',
    name: 'Cubiertos Postre Hudson',
    description: 'Set de cubiertos para postre',
    price: 28999.99,
    imageUrl: 'https://images.unsplash.com/photo-1544829885-75d3c7e9e73e?w=1080&h=1080&fit=crop',
    category: 'Cubiertos',
    stock: 30,
    color: 'Dorado'
  },
  {
    id: 'cubiertos-3',
    name: 'Set Servir Hudson',
    description: 'Set de cubiertos para servir',
    price: 22999.99,
    imageUrl: 'https://images.unsplash.com/photo-1544829885-75d3c7e9e73e?w=1080&h=1080&fit=crop',
    category: 'Cubiertos',
    stock: 25,
    color: 'Plateado'
  }
];