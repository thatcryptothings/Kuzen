import { Product } from '../../types';

export const desayunoProducts: Product[] = [
  {
    id: 'desayuno-1',
    name: 'Tostadora Hudson Pro',
    description: 'Tostadora de 2 ranuras con control de temperatura',
    price: 28999.99,
    imageUrl: 'https://images.unsplash.com/photo-1622021142947-da7dedc7c39a?w=1080&h=1080&fit=crop',
    category: 'Desayuno y Merienda',
    stock: 20,
    color: 'Plateado'
  },
  {
    id: 'desayuno-2',
    name: 'Cafetera Hudson Express',
    description: 'Cafetera de filtro programable',
    price: 35999.99,
    imageUrl: 'https://images.unsplash.com/photo-1606483956061-46a898dce538?w=1080&h=1080&fit=crop',
    category: 'Desayuno y Merienda',
    stock: 15,
    color: 'Negro'
  },
  {
    id: 'desayuno-3',
    name: 'Pava Eléctrica Hudson',
    description: 'Pava eléctrica con control de temperatura',
    price: 22999.99,
    imageUrl: 'https://images.unsplash.com/photo-1594213114663-d94db9b17125?w=1080&h=1080&fit=crop',
    category: 'Desayuno y Merienda',
    stock: 25,
    color: 'Plateado'
  }
];