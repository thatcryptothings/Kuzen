import { Product } from '../../types';

export const cuchillosProducts: Product[] = [
  {
    id: 'cuchillos-1',
    name: 'Set Cuchillos Hudson Pro',
    description: 'Set de 6 cuchillos profesionales con soporte',
    price: 89999.99,
    imageUrl: 'https://images.unsplash.com/photo-1593618997811-a3c85263429c?w=1080&h=1080&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1594226801341-41427b755b88?w=1080&h=1080&fit=crop'
    ],
    category: 'Cuchillos',
    labels: ['Premium'],
    stock: 10,
    color: 'Negro'
  },
  {
    id: 'cuchillos-2',
    name: 'Cuchillo Chef Hudson',
    description: 'Cuchillo de chef de 8 pulgadas',
    price: 25999.99,
    imageUrl: 'https://images.unsplash.com/photo-1593618997771-c313826e0f8e?w=1080&h=1080&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1608163364633-97c1d5d6d23b?w=1080&h=1080&fit=crop'
    ],
    category: 'Cuchillos',
    stock: 20,
    size: {
      value: 8,
      unit: 'in'
    },
    color: 'Plateado'
  },
  {
    id: 'cuchillos-3',
    name: 'Afilador Hudson Diamond',
    description: 'Afilador de cuchillos profesional con base diamantada',
    price: 18999.99,
    imageUrl: 'https://images.unsplash.com/photo-1594226801341-41427b755b88?w=1080&h=1080&fit=crop',
    images: [
      'https://images.unsplash.com/photo-1593618997771-c313826e0f8e?w=1080&h=1080&fit=crop'
    ],
    category: 'Cuchillos',
    stock: 25,
    color: 'Negro'
  }
];