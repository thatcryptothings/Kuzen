import { Promotion } from '../types';

export const promotions: Promotion[] = [
  {
    id: '1',
    title: '¡Set de Cuchillos Profesionales!',
    description: 'Descubre nuestra línea premium de cuchillos Hudson',
    imageUrl: 'https://images.unsplash.com/photo-1593618997771-c313826e0f8e?w=1080&h=1080&fit=crop',
    productId: '5'
  },
  {
    id: '2',
    title: 'Vajilla Completa Hudson',
    description: 'Elegancia y calidad para tu mesa',
    imageUrl: 'https://images.unsplash.com/photo-1603199506016-b9a594b593c0?w=1080&h=1080&fit=crop',
    productId: '7'
  },
  {
    id: '3',
    title: 'Ollas Profesionales',
    description: 'Para los chefs más exigentes',
    imageUrl: 'https://images.unsplash.com/photo-1592156328697-079f6bd49e39?w=1080&h=1080&fit=crop',
    productId: '1'
  }
];