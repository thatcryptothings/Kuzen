export interface SalesRep {
  id: string;
  name: string;
  email: string;
  phone: string;
  active: boolean;
  totalSales: number;
}

export interface StoreState {
  // Products
  products: Product[];
  selectedCategory: string | null;
  searchQuery: string;
  
  // Cart
  cart: CartItem[];
  addToCart: (product: Product) => void;
  removeFromCart: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;

  // Sales Reps
  salesReps: SalesRep[];
  addSalesRep: (rep: Omit<SalesRep, 'id' | 'active' | 'totalSales'>) => void;
  updateSalesRep: (id: string, updates: Partial<SalesRep>) => void;
  toggleSalesRepStatus: (id: string) => void;
  deleteSalesRep: (id: string) => void;

  // Settings
  paymentSettings: PaymentSettings;
  updatePaymentSettings: (settings: PaymentSettings) => void;
}

export interface PaymentSettings {
  transfer: {
    bankName: string;
    accountHolder: string;
    accountNumber: string;
    cbu: string;
    alias: string;
  };
  mercadoPago: {
    link: string;
    qrCode: string;
    username: string;
  };
}

export type PaymentMethod = 'cash' | 'transfer' | 'mercadopago';

export interface CustomerInfo {
  name: string;
  email: string;
  phone: string;
  notes?: string;
  salesRep: string;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  imageUrl: string;
  images?: string[];
  category: string;
  labels?: string[];
  stock: number;
  size?: {
    value: number;
    unit: 'cm' | 'in';
  };
  color?: string;
  visible?: boolean;
  sales?: number;
  lastSale?: string;
}