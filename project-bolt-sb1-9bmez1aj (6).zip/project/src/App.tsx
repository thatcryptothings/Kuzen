import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AdminHeader } from './components/AdminHeader';
import { UserHeader } from './components/UserHeader';
import { ProductGrid } from './components/ProductGrid';
import { CategoryFilter } from './components/CategoryFilter';
import { SearchBar } from './components/SearchBar';
import { Cart } from './components/Cart';
import { CategoriesPage } from './components/CategoriesPage';
import { AdminLogin } from './components/AdminLogin';
import { ProductManager } from './components/ProductManager';
import { CustomerDashboard } from './components/CustomerDashboard';
import { AdminSettings } from './components/settings/AdminSettings';
import { BackToTop } from './components/common/BackToTop';

const App: React.FC = () => {
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    const adminStatus = localStorage.getItem('isAdmin');
    setIsAdmin(adminStatus === 'true');
  }, []);

  const handleLogin = () => {
    setIsAdmin(true);
  };

  const handleLogout = () => {
    localStorage.removeItem('isAdmin');
    setIsAdmin(false);
  };

  if (!isAdmin && window.location.pathname.startsWith('/admin')) {
    return <AdminLogin onLogin={handleLogin} />;
  }

  return (
    <Router>
      <div className="min-h-screen bg-white">
        {isAdmin ? (
          <AdminHeader onLogout={handleLogout} />
        ) : (
          <UserHeader onCartClick={() => setIsCartOpen(true)} />
        )}

        <Routes>
          <Route path="/" element={<CategoriesPage />} />
          <Route
            path="/products"
            element={
              <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                {isAdmin ? (
                  <ProductManager />
                ) : (
                  <>
                    <SearchBar />
                    <CategoryFilter />
                    <ProductGrid />
                  </>
                )}
              </main>
            }
          />
          <Route
            path="/admin/customers"
            element={isAdmin ? <CustomerDashboard /> : <Navigate to="/admin" />}
          />
          <Route
            path="/admin/settings"
            element={isAdmin ? <AdminSettings /> : <Navigate to="/admin" />}
          />
          <Route
            path="/admin/*"
            element={isAdmin ? <Navigate to="/products" /> : <AdminLogin onLogin={handleLogin} />}
          />
        </Routes>

        {!isAdmin && <Cart isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />}
        <BackToTop />
      </div>
    </Router>
  );
};

export default App;