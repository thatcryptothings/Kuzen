import { CartItem, CustomerInfo, PaymentMethod } from '../types';

export class WhatsAppService {
  private static readonly API_BASE = 'https://api.whatsapp.com/send';
  private static readonly FALLBACK_API = 'https://wa.me';

  private static cleanPhoneNumber(phone: string): string {
    const cleaned = phone.replace(/\D/g, '');
    if (!cleaned.match(/^\d{10,}$/)) {
      throw new Error('Número de teléfono inválido');
    }
    return cleaned;
  }

  private static formatCurrency(amount: number): string {
    return new Intl.NumberFormat('es-AR', {
      style: 'currency',
      currency: 'ARS'
    }).format(amount);
  }

  private static formatOrderDetails(cart: CartItem[]): string {
    return cart
      .map(item => {
        const total = this.formatCurrency(item.price * item.quantity);
        return `• ${item.quantity}x ${item.name} - ${total}`;
      })
      .join('\n');
  }

  private static formatPaymentMethod(method: PaymentMethod): string {
    const methods = {
      cash: '💵 Efectivo',
      transfer: '🏦 Transferencia Bancaria',
      mercadopago: '💳 Mercado Pago'
    };
    return methods[method];
  }

  public static createOrderMessage(
    cart: CartItem[],
    customerInfo: CustomerInfo,
    paymentMethod: PaymentMethod,
    paymentProofUrl?: string,
    forSalesRep: boolean = false
  ): string {
    const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const orderDetails = this.formatOrderDetails(cart);
    const orderNumber = `ORD-${Date.now().toString(36).toUpperCase()}`;

    const message = [
      `🛍️ *${forSalesRep ? 'Nuevo Pedido Asignado' : 'Pedido Confirmado'}*`,
      `📋 *Orden:* ${orderNumber}\n`,
      `👤 *Información del Cliente:*`,
      `• Nombre: ${customerInfo.name}`,
      `• Email: ${customerInfo.email}`,
      `• Teléfono: ${customerInfo.phone}`,
      customerInfo.notes ? `\n📝 *Notas:*\n${customerInfo.notes}` : '',
      `\n💰 *Método de Pago:*`,
      this.formatPaymentMethod(paymentMethod),
      paymentProofUrl ? `\n🧾 *Comprobante de Pago:*\n${paymentProofUrl}` : '',
      `\n📦 *Detalles del Pedido:*`,
      orderDetails,
      `\n💵 *Total:* ${this.formatCurrency(total)}`,
      `\n✅ *Estado:* ${forSalesRep ? 'Pendiente de procesamiento' : 'En preparación'}`,
      forSalesRep ? '\n⚡ Por favor, procesa este pedido lo antes posible.' : '\n🎉 ¡Gracias por tu compra!'
    ].filter(Boolean).join('\n');

    return message;
  }

  public static async createMessageUrl(phone: string, message: string): Promise<string> {
    const cleanPhone = this.cleanPhoneNumber(phone);
    const encodedMessage = encodeURIComponent(message);

    // Try primary API first
    const primaryUrl = `${this.API_BASE}?phone=${cleanPhone}&text=${encodedMessage}`;
    
    try {
      const response = await fetch(primaryUrl, { method: 'HEAD' });
      if (response.ok) {
        return primaryUrl;
      }
    } catch {
      // Fallback to wa.me if primary API fails
      return `${this.FALLBACK_API}/${cleanPhone}?text=${encodedMessage}`;
    }

    return primaryUrl;
  }

  public static async openWhatsApp(url: string): Promise<void> {
    return new Promise((resolve, reject) => {
      // First test if popups are allowed
      const testWindow = window.open('about:blank', '_blank');
      if (!testWindow) {
        reject(new Error('Por favor, permita las ventanas emergentes para continuar'));
        return;
      }
      testWindow.close();

      // Open WhatsApp in a new window
      const whatsappWindow = window.open(url, '_blank');
      if (!whatsappWindow) {
        reject(new Error('Error al abrir WhatsApp. Por favor, intente nuevamente'));
        return;
      }

      // Set up a check for window closure
      let attempts = 0;
      const maxAttempts = 10;
      const checkInterval = setInterval(() => {
        attempts++;
        if (whatsappWindow.closed || attempts >= maxAttempts) {
          clearInterval(checkInterval);
          resolve();
        }
      }, 1000);

      // Cleanup after 10 seconds
      setTimeout(() => {
        clearInterval(checkInterval);
        resolve();
      }, 10000);
    });
  }
}