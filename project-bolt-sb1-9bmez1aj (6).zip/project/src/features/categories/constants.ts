// Define category-related constants
export const ALL_CATEGORIES_ID = null;
export const ALL_CATEGORIES_LABEL = 'Todos';