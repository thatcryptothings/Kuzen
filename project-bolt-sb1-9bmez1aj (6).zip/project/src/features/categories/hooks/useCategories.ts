import { useCallback, useMemo } from 'react';
import { useStore } from '../../../store/useStore';
import { ALL_CATEGORIES_ID, ALL_CATEGORIES_LABEL } from '../constants';
import { CategoryOption } from '../types';
import { useCategoryList } from './useCategoryList';

export const useCategories = () => {
  const selectedCategory = useStore((state) => state.selectedCategory);
  const setSelectedCategory = useStore((state) => state.setSelectedCategory);
  const categories = useCategoryList();

  const categoryOptions = useMemo(() => {
    // Ensure "Todos" is always first
    const options: CategoryOption[] = [
      { id: ALL_CATEGORIES_ID, label: ALL_CATEGORIES_LABEL }
    ];

    // Add other categories
    categories.forEach(category => {
      options.push({
        id: category,
        label: category
      });
    });

    return options;
  }, [categories]);

  const handleCategorySelect = useCallback((categoryId: string | null) => {
    setSelectedCategory(categoryId === ALL_CATEGORIES_ID ? null : categoryId);
  }, [setSelectedCategory]);

  return {
    categories: categoryOptions,
    selectedCategory,
    handleCategorySelect,
  };
};