export interface CategoryOption {
  id: string | null;
  label: string;
}