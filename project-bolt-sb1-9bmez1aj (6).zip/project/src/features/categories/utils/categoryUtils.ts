import { Product } from '../../../types';

export const filterProductsByCategory = (
  products: Product[],
  selectedCategory: string | null
): Product[] => {
  // If no category is selected or it's explicitly ALL_CATEGORIES_ID, return all products
  if (!selectedCategory) {
    return products;
  }
  
  // Filter by selected category
  return products.filter((product) => product.category === selectedCategory);
};