import { useState, useCallback } from 'react';
import { WhatsAppService } from '../services/whatsapp';
import { CartItem, CustomerInfo, PaymentMethod } from '../types';

interface UseWhatsAppOptions {
  onSuccess?: () => void;
  onError?: (error: Error) => void;
}

export const useWhatsApp = (options: UseWhatsAppOptions = {}) => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string>('');

  const sendOrder = useCallback(async (
    phone: string,
    cart: CartItem[],
    customerInfo: CustomerInfo,
    paymentMethod: PaymentMethod,
    paymentProofUrl?: string,
    forSalesRep: boolean = false
  ): Promise<void> => {
    setIsLoading(true);
    setError('');

    try {
      const message = WhatsAppService.createOrderMessage(
        cart,
        customerInfo,
        paymentMethod,
        paymentProofUrl,
        forSalesRep
      );

      const url = await WhatsAppService.createMessageUrl(phone, message);
      await WhatsAppService.openWhatsApp(url);
      
      options.onSuccess?.();
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Error al enviar el mensaje';
      setError(errorMessage);
      options.onError?.(new Error(errorMessage));
    } finally {
      setIsLoading(false);
    }
  }, [options]);

  const clearError = useCallback(() => {
    setError('');
  }, []);

  return {
    isLoading,
    error,
    sendOrder,
    clearError
  };
};