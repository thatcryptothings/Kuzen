import { useMemo } from 'react';
import { Product } from '../types';

export const useProductFiltering = (
  products: Product[],
  selectedCategory: string | null,
  searchQuery: string
) => {
  return useMemo(() => {
    // First filter out hidden products
    let filteredProducts = products.filter(product => product.visible !== false);

    // Then apply category filter if selected
    if (selectedCategory && selectedCategory !== 'Todos') {
      filteredProducts = filteredProducts.filter(
        (product) => product.category === selectedCategory
      );
    }

    // Finally apply search filter if there's a query
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase().trim();
      filteredProducts = filteredProducts.filter(
        (product) =>
          product.name.toLowerCase().includes(query) ||
          product.description.toLowerCase().includes(query)
      );
    }

    return filteredProducts;
  }, [products, selectedCategory, searchQuery]);
};