import { useMemo } from 'react';
import { optimizeImageUrl } from '../utils/imageOptimizer';

export const useProductImages = () => {
  const getOptimizedImageUrl = useMemo(() => (url: string) => {
    return optimizeImageUrl(url, 'product');
  }, []);

  return {
    getOptimizedImageUrl,
  };
};