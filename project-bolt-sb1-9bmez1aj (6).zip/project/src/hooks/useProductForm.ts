import { useState, useCallback } from 'react';
import { Product } from '../types';
import { useImageUpload } from './useImageUpload';

const initialFormState = {
  name: '',
  description: '',
  price: 0,
  imageUrl: '',
  images: [],
  category: '',
  labels: [],
  stock: 0,
  size: {
    width: {
      value: 0,
      unit: 'cm' as const
    },
    height: {
      value: 0,
      unit: 'cm' as const
    }
  },
  color: '',
  visible: true,
  sales: 0
};

export const useProductForm = (
  initialProduct: Product | null | undefined,
  onSubmit: (product: Product) => void
) => {
  const [formData, setFormData] = useState<Partial<Product>>(
    initialProduct || initialFormState
  );

  const {
    images,
    error,
    handleImageUpload,
    removeImage: handleRemoveImage,
  } = useImageUpload(4);

  const handleInputChange = useCallback((field: keyof Product | 'size', value: any) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  }, []);

  const handleSubmit = useCallback((e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.imageUrl && images.length === 0) {
      alert('Debes subir al menos una imagen');
      return;
    }

    if (formData.name && formData.price !== undefined && formData.category) {
      const productData = {
        ...formData,
        imageUrl: images[0] || formData.imageUrl,
        images: images.slice(1),
      } as Product;
      
      onSubmit(productData);
    }
  }, [formData, images, onSubmit]);

  return {
    formData,
    images,
    error,
    handleInputChange,
    handleImageUpload,
    handleRemoveImage,
    handleSubmit
  };
};