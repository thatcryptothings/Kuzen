import { useMemo } from 'react';
import { useStore } from '../store/useStore';

export const useCategoryList = () => {
  const products = useStore((state) => state.products);
  
  return useMemo(() => {
    const categories = Array.from(new Set(products.map((product) => product.category)))
      .sort((a, b) => a.localeCompare(b));
    return categories;
  }, [products]);
};