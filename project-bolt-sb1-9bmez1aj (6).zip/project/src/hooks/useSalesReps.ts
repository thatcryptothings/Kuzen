import { useCallback } from 'react';
import { useStore } from '../store/useStore';
import { SalesRep } from '../types';

export const useSalesReps = () => {
  const {
    salesReps,
    addSalesRep: addRep,
    updateSalesRep: updateRep,
    toggleSalesRepStatus,
    deleteSalesRep
  } = useStore();

  const activeSalesReps = salesReps.filter(rep => rep.active);

  const validateSalesRep = useCallback((data: Partial<SalesRep>): string | null => {
    if (!data.name?.trim()) {
      return 'El nombre es requerido';
    }

    if (!data.email?.trim()) {
      return 'El email es requerido';
    }

    if (!data.phone?.trim()) {
      return 'El teléfono es requerido';
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email)) {
      return 'El email no es válido';
    }

    const phoneRegex = /^\+?[\d\s-]{10,}$/;
    if (!phoneRegex.test(data.phone.replace(/\s+/g, ''))) {
      return 'El teléfono debe incluir código de país';
    }

    return null;
  }, []);

  const addSalesRep = useCallback(async (data: Omit<SalesRep, 'id' | 'active' | 'totalSales'>) => {
    const error = validateSalesRep(data);
    if (error) throw new Error(error);
    addRep(data);
  }, [addRep, validateSalesRep]);

  const updateSalesRep = useCallback(async (id: string, updates: Partial<SalesRep>) => {
    const error = validateSalesRep(updates);
    if (error) throw new Error(error);
    updateRep(id, updates);
  }, [updateRep, validateSalesRep]);

  return {
    salesReps,
    activeSalesReps,
    addSalesRep,
    updateSalesRep,
    toggleSalesRepStatus,
    deleteSalesRep,
    validateSalesRep
  };
};