import { useCallback } from 'react';

export const useCopyToClipboard = () => {
  const copyToClipboard = useCallback((text: string) => {
    navigator.clipboard.writeText(text);
    alert('Copiado al portapapeles');
  }, []);

  return { copyToClipboard };
};