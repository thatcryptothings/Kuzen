import { useCallback } from 'react';
import { useStore } from '../store/useStore';
import { Product } from '../types';

export const useCart = () => {
  const {
    cart,
    addToCart,
    removeFromCart,
    updateQuantity,
    clearCart,
    products
  } = useStore();

  const getAvailableStock = useCallback((productId: string) => {
    const product = products.find(p => p.id === productId);
    if (!product) return 0;
    
    const cartItem = cart.find(item => item.id === productId);
    const currentQuantity = cartItem?.quantity || 0;
    
    return product.stock - currentQuantity;
  }, [products, cart]);

  const addItem = useCallback((product: Product) => {
    const availableStock = getAvailableStock(product.id);
    if (availableStock > 0) {
      addToCart(product);
      return true;
    }
    return false;
  }, [addToCart, getAvailableStock]);

  const updateItemQuantity = useCallback((productId: string, quantity: number) => {
    const product = products.find(p => p.id === productId);
    if (!product || quantity > product.stock) {
      return false;
    }
    updateQuantity(productId, quantity);
    return true;
  }, [products, updateQuantity]);

  const total = cart.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  return {
    cart,
    total,
    addItem,
    removeFromCart,
    updateItemQuantity,
    clearCart,
    getAvailableStock,
  };
};