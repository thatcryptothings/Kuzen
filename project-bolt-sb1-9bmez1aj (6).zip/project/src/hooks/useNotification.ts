import { useState } from 'react';

interface UseNotificationOptions {
  onSuccess?: () => void;
  onError?: (error: Error) => void;
}

export const useNotification = (options: UseNotificationOptions = {}) => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string>('');

  const sendNotification = async (url: string): Promise<void> => {
    setIsLoading(true);
    setError('');

    try {
      // First try to detect if popups are blocked
      const test = window.open('about:blank', '_blank');
      if (!test) {
        throw new Error('Por favor, permita las ventanas emergentes para continuar');
      }
      test.close();

      // Now open the actual WhatsApp link
      const whatsappWindow = window.open(url, '_blank');
      if (!whatsappWindow) {
        throw new Error('Error al abrir WhatsApp. Por favor, intente nuevamente');
      }

      options.onSuccess?.();
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Error al enviar la notificación';
      setError(errorMessage);
      options.onError?.(new Error(errorMessage));
    } finally {
      setIsLoading(false);
    }
  };

  return {
    isLoading,
    error,
    sendNotification,
    clearError: () => setError('')
  };
};