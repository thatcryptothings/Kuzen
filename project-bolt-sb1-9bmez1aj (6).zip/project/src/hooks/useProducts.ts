import { useCallback } from 'react';
import { useStore } from '../store/useStore';
import { Product } from '../types';

export const useProducts = () => {
  const {
    products,
    visibleProducts,
    hiddenProducts,
    addProduct,
    updateProduct,
    deleteProduct,
    toggleProductVisibility
  } = useStore();

  const handleAddProduct = useCallback((product: Omit<Product, 'id' | 'visible' | 'sales'>) => {
    addProduct(product);
  }, [addProduct]);

  const handleUpdateProduct = useCallback((id: string, updates: Partial<Product>) => {
    updateProduct(id, updates);
  }, [updateProduct]);

  const handleDeleteProduct = useCallback((id: string) => {
    if (window.confirm('¿Estás seguro de que deseas eliminar este producto?')) {
      deleteProduct(id);
    }
  }, [deleteProduct]);

  const handleToggleVisibility = useCallback((id: string) => {
    toggleProductVisibility(id);
  }, [toggleProductVisibility]);

  return {
    products,
    visibleProducts,
    hiddenProducts,
    addProduct: handleAddProduct,
    updateProduct: handleUpdateProduct,
    deleteProduct: handleDeleteProduct,
    toggleVisibility: handleToggleVisibility
  };
};