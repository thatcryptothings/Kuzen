import { useState } from 'react';
import { validateImage } from '../utils/imageValidator';

export const useImageUpload = (maxImages: number = 4) => {
  const [images, setImages] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);

  const handleImageUpload = async (file: File) => {
    try {
      if (images.length >= maxImages) {
        throw new Error(`No puedes subir más de ${maxImages} imágenes`);
      }

      await validateImage(file);
      
      const reader = new FileReader();
      reader.onload = (e) => {
        const result = e.target?.result as string;
        setImages(prev => [...prev, result]);
        setError(null);
      };
      reader.readAsDataURL(file);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error al procesar la imagen');
    }
  };

  const removeImage = (index: number) => {
    setImages(prev => prev.filter((_, i) => i !== index));
  };

  const clearImages = () => {
    setImages([]);
    setError(null);
  };

  return {
    images,
    error,
    handleImageUpload,
    removeImage,
    clearImages,
    isFull: images.length >= maxImages
  };
};