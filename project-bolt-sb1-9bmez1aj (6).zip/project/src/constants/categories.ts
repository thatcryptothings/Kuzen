export const categories = [
  'Ollas, Sartenes y Jarros',
  'Desayuno y Merienda',
  'Cuchillos',
  'Vajilla y Cristalería',
  'Horno',
  'Cubiertos',
  'Asado',
  'Utensilios y Más'
];