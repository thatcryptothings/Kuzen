export const paymentInfo = {
  transfer: {
    bankName: "Banco Nación",
    accountHolder: "Hudson Kitchen",
    accountNumber: "0000000000000000000000",
    cbu: "0000000000000000000000",
    alias: "HUDSON.KITCHEN",
  },
  mercadoPago: {
    link: "https://link.mercadopago.com.ar/hudsonkitchen",
    qrCode: "https://www.mercadopago.com.ar/qr/000000000",
    username: "@hudsonkitchen",
  }
};